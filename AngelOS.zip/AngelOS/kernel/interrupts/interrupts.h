#ifndef HALOROOT_INTERRUPTS_H
#define HALOROOT_INTERRUPTS_H

#include <stdint.h>

struct interrupt_frame {
    uint64_t r15;
    uint64_t r14;
    uint64_t r13;
    uint64_t r12;
    uint64_t r11;
    uint64_t r10;
    uint64_t r9;
    uint64_t r8;

    uint64_t rdi;
    uint64_t rsi;
    uint64_t rbp;
    uint64_t rdx;
    uint64_t rcx;
    uint64_t rbx;
    uint64_t rax;

    uint64_t vector;
    uint64_t error_code;

    uint64_t rip;
    uint64_t cs;
    uint64_t rflags;
};

typedef void (*irq_handler_t)(struct interrupt_frame *frame);

int interrupts_init(void);

int irq_register_handler(
    uint8_t irq,
    irq_handler_t handler
);

void interrupt_dispatch(struct interrupt_frame *frame);

__attribute__((noreturn))
void exception_handler(struct interrupt_frame *frame);

void interrupts_test_divide_by_zero(void);
void interrupts_test_invalid_opcode(void);
void interrupts_test_page_fault(void);

#endif