
bits 64
default rel

section .text

extern interrupt_dispatch

; Interrupts without CPU-pushed error codes.

%macro ISR_NO_ERROR 1
global isr%1

isr%1:
    push qword 0
    push qword %1
    jmp isr_common
%endmacro

; Exceptions with CPU-pushed error codes.

%macro ISR_ERROR 1
global isr%1

isr%1:
    push qword %1
    jmp isr_common
%endmacro

; ==========================================
; CPU EXCEPTIONS (VECTORS 0-31)
; ==========================================

ISR_NO_ERROR 0
ISR_NO_ERROR 1
ISR_NO_ERROR 2
ISR_NO_ERROR 3
ISR_NO_ERROR 4
ISR_NO_ERROR 5
ISR_NO_ERROR 6
ISR_NO_ERROR 7

ISR_ERROR 8
ISR_NO_ERROR 9
ISR_ERROR 10
ISR_ERROR 11
ISR_ERROR 12
ISR_ERROR 13
ISR_ERROR 14
ISR_NO_ERROR 15
ISR_NO_ERROR 16
ISR_ERROR 17
ISR_NO_ERROR 18
ISR_NO_ERROR 19
ISR_NO_ERROR 20
ISR_ERROR 21
ISR_NO_ERROR 22
ISR_NO_ERROR 23
ISR_NO_ERROR 24
ISR_NO_ERROR 25
ISR_NO_ERROR 26
ISR_NO_ERROR 27
ISR_NO_ERROR 28
ISR_ERROR 29
ISR_ERROR 30
ISR_NO_ERROR 31

; ==========================================
; HARDWARE INTERRUPTS (VECTORS 32-47)
; ==========================================

ISR_NO_ERROR 32
ISR_NO_ERROR 33
ISR_NO_ERROR 34
ISR_NO_ERROR 35
ISR_NO_ERROR 36
ISR_NO_ERROR 37
ISR_NO_ERROR 38
ISR_NO_ERROR 39

ISR_NO_ERROR 40
ISR_NO_ERROR 41
ISR_NO_ERROR 42
ISR_NO_ERROR 43
ISR_NO_ERROR 44
ISR_NO_ERROR 45
ISR_NO_ERROR 46
ISR_NO_ERROR 47

; ==========================================
; DEFAULT HANDLER
; ==========================================

global isr_default_stub

isr_default_stub:
    push qword 0
    push qword 255
    jmp isr_common

; ==========================================
; COMMON INTERRUPT HANDLER
; ==========================================
;
; Stack layout passed to C:
;
; r15 ... r8
; rdi, rsi, rbp, rdx, rcx, rbx, rax
; vector
; error_code
; RIP
; CS
; RFLAGS
;

isr_common:
    cld

    ; Save general-purpose registers.

    push rax
    push rbx
    push rcx
    push rdx
    push rbp
    push rsi
    push rdi

    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15

    ; Pass the interrupt frame to C.

    mov rdi, rsp

    ; Preserve original stack position.
    ; Align stack for the x86-64 C ABI.

    mov rbx, rsp
    and rsp, -16

    call interrupt_dispatch

    ; Restore original stack.

    mov rsp, rbx

    ; Restore registers.

    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8

    pop rdi
    pop rsi
    pop rbp
    pop rdx
    pop rcx
    pop rbx
    pop rax

    ; Remove vector and error code.

    add rsp, 16

    ; Return from interrupt.

    iretq

; ==========================================
; INTERRUPT STUB TABLE
; ==========================================

section .rodata
align 8

global isr_stub_table

isr_stub_table:

    ; CPU exceptions: 0-31

    dq isr0
    dq isr1
    dq isr2
    dq isr3
    dq isr4
    dq isr5
    dq isr6
    dq isr7
    dq isr8
    dq isr9
    dq isr10
    dq isr11
    dq isr12
    dq isr13
    dq isr14
    dq isr15
    dq isr16
    dq isr17
    dq isr18
    dq isr19
    dq isr20
    dq isr21
    dq isr22
    dq isr23
    dq isr24
    dq isr25
    dq isr26
    dq isr27
    dq isr28
    dq isr29
    dq isr30
    dq isr31

    ; Hardware IRQs: 32-47

    dq isr32
    dq isr33
    dq isr34
    dq isr35
    dq isr36
    dq isr37
    dq isr38
    dq isr39
    dq isr40
    dq isr41
    dq isr42
    dq isr43
    dq isr44
    dq isr45
    dq isr46
    dq isr47
