
#ifndef HALOROOT_IDT_H
#define HALOROOT_IDT_H

#include <stdint.h>

int idt_init(void);

#endif
