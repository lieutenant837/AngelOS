#include "interrupts.h"
#include "idt.h"
#include "pic.h"

/* Serial functions provided by main.c. */
extern void serial_write(const char *text);
extern void serial_write_hex(uint64_t value);

static irq_handler_t irq_handlers[16];

static const char *exception_name(uint64_t vector)
{
    switch (vector) {
        case 0:  return "Divide Error";
        case 1:  return "Debug";
        case 2:  return "Non-Maskable Interrupt";
        case 3:  return "Breakpoint";
        case 4:  return "Overflow";
        case 5:  return "Bound Range Exceeded";
        case 6:  return "Invalid Opcode";
        case 7:  return "Device Not Available";
        case 8:  return "Double Fault";
        case 9:  return "Coprocessor Segment Overrun";
        case 10: return "Invalid TSS";
        case 11: return "Segment Not Present";
        case 12: return "Stack-Segment Fault";
        case 13: return "General Protection Fault";
        case 14: return "Page Fault";
        case 15: return "Reserved";
        case 16: return "x87 Floating-Point Exception";
        case 17: return "Alignment Check";
        case 18: return "Machine Check";
        case 19: return "SIMD Floating-Point Exception";
        case 20: return "Virtualization Exception";
        case 21: return "Control Protection Exception";
        case 22: return "Reserved";
        case 23: return "Reserved";
        case 24: return "Reserved";
        case 25: return "Reserved";
        case 26: return "Reserved";
        case 27: return "Reserved";
        case 28: return "Hypervisor Injection Exception";
        case 29: return "VMM Communication Exception";
        case 30: return "Security Exception";
        case 31: return "Reserved";
        default: return "Unknown Interrupt";
    }
}

static void print_page_fault_information(uint64_t error_code)
{
    uint64_t fault_address;

    __asm__ volatile (
        "mov %%cr2, %0"
        : "=r"(fault_address)
    );

    serial_write("[FAULT] Faulting virtual address: ");
    serial_write_hex(fault_address);
    serial_write("\n");

    serial_write("[FAULT] Page fault reason:\n");

    serial_write(
        (error_code & 1)
        ? "  - Protection violation\n"
        : "  - Page not present\n"
    );

    serial_write(
        (error_code & 2)
        ? "  - Write access\n"
        : "  - Read access\n"
    );

    serial_write(
        (error_code & 4)
        ? "  - User-mode access\n"
        : "  - Supervisor-mode access\n"
    );

    if (error_code & 8) {
        serial_write("  - Reserved page-table bit violation\n");
    }

    if (error_code & 16) {
        serial_write("  - Instruction fetch\n");
    }
}

int interrupts_init(void)
{
    return idt_init();
}

int irq_register_handler(uint8_t irq, irq_handler_t handler)
{
    if (irq >= 16 || handler == 0) {
        return 0;
    }

    irq_handlers[irq] = handler;
    return 1;
}

void interrupt_dispatch(struct interrupt_frame *frame)
{
    uint64_t vector = frame->vector;

    /* CPU exceptions: vectors 0-31. */
    if (vector < 32) {
        exception_handler(frame);
    }

    /* Hardware IRQs: vectors 32-47. */
    if (vector >= 32 && vector <= 47) {
        uint8_t irq = (uint8_t)(vector - 32);

        if (irq_handlers[irq] != 0) {
            irq_handlers[irq](frame);
        }

        /* Tell the PIC that the interrupt has been handled. */
        pic_send_eoi(irq);
        return;
    }

    /* Unexpected interrupt. */
    exception_handler(frame);
}

__attribute__((noreturn))
void exception_handler(struct interrupt_frame *frame)
{
    serial_write("\n");
    serial_write("====================================\n");
    serial_write("       HALOROOT CPU EXCEPTION       \n");
    serial_write("====================================\n");

    serial_write("[EXCEPTION] Vector: ");
    serial_write_hex(frame->vector);
    serial_write("\n");

    serial_write("[EXCEPTION] Name: ");
    serial_write(exception_name(frame->vector));
    serial_write("\n");

    serial_write("[EXCEPTION] Error code: ");
    serial_write_hex(frame->error_code);
    serial_write("\n");

    serial_write("[EXCEPTION] Instruction address: ");
    serial_write_hex(frame->rip);
    serial_write("\n");

    serial_write("[EXCEPTION] Code segment: ");
    serial_write_hex(frame->cs);
    serial_write("\n");

    serial_write("[EXCEPTION] CPU flags: ");
    serial_write_hex(frame->rflags);
    serial_write("\n");

    if (frame->vector == 14) {
        print_page_fault_information(frame->error_code);
    }

    serial_write("====================================\n");
    serial_write("[HALOROOT] System halted due to CPU exception.\n");

    for (;;) {
        __asm__ volatile ("cli; hlt");
    }
}

/* Exception tests remain available for later use. */

void interrupts_test_divide_by_zero(void)
{
    __asm__ volatile (
        "xorq %%rdx, %%rdx\n\t"
        "movq $1, %%rax\n\t"
        "xorq %%rcx, %%rcx\n\t"
        "divq %%rcx"
        :
        :
        : "rax", "rdx", "rcx", "cc"
    );
}

void interrupts_test_invalid_opcode(void)
{
    __asm__ volatile ("ud2");
}

void interrupts_test_page_fault(void)
{
    volatile uint64_t *bad_address =
        (volatile uint64_t *)0x0000400000000000ULL;

    volatile uint64_t value = *bad_address;

    (void)value;
}