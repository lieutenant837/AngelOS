#include "pic.h"

#define PIC1_COMMAND 0x20
#define PIC1_DATA    0x21
#define PIC2_COMMAND 0xA0
#define PIC2_DATA    0xA1

#define PIC_EOI      0x20

static inline void outb(uint16_t port, uint8_t value)
{
    __asm__ volatile (
        "outb %0, %1"
        :
        : "a"(value), "Nd"(port)
    );
}

static inline uint8_t inb(uint16_t port)
{
    uint8_t value;

    __asm__ volatile (
        "inb %1, %0"
        : "=a"(value)
        : "Nd"(port)
    );

    return value;
}

static void io_wait(void)
{
    outb(0x80, 0);
}

void pic_init(void)
{
    /* Disable interrupts while configuring the PIC. */
    __asm__ volatile ("cli");

    /* Save the current masks. */
    uint8_t master_mask = inb(PIC1_DATA);
    uint8_t slave_mask = inb(PIC2_DATA);

    /* Begin PIC initialization. */
    outb(PIC1_COMMAND, 0x11);
    io_wait();

    outb(PIC2_COMMAND, 0x11);
    io_wait();

    /* Remap master to vectors 32-39. */
    outb(PIC1_DATA, 0x20);
    io_wait();

    /* Remap slave to vectors 40-47. */
    outb(PIC2_DATA, 0x28);
    io_wait();

    /* Tell master and slave about their cascade connection. */
    outb(PIC1_DATA, 0x04);
    io_wait();

    outb(PIC2_DATA, 0x02);
    io_wait();

    /* Use 8086 mode. */
    outb(PIC1_DATA, 0x01);
    io_wait();

    outb(PIC2_DATA, 0x01);
    io_wait();

    /*
     * Mask all IRQs initially.
     * We'll explicitly enable the timer and keyboard later.
     */
    outb(PIC1_DATA, 0xFF);
    outb(PIC2_DATA, 0xFF);

    (void)master_mask;
    (void)slave_mask;
}

void pic_unmask_irq(uint8_t irq)
{
    if (irq >= 16) {
        return;
    }

    uint16_t port;
    uint8_t mask;

    if (irq < 8) {
        port = PIC1_DATA;
    } else {
        port = PIC2_DATA;
        irq -= 8;
    }

    mask = inb(port);
    mask &= (uint8_t)~(1U << irq);
    outb(port, mask);

    /* The slave PIC is connected through master IRQ2. */
    if (port == PIC2_DATA) {
        mask = inb(PIC1_DATA);
        mask &= (uint8_t)~(1U << 2);
        outb(PIC1_DATA, mask);
    }
}

void pic_mask_irq(uint8_t irq)
{
    if (irq >= 16) {
        return;
    }

    uint16_t port;

    if (irq < 8) {
        port = PIC1_DATA;
    } else {
        port = PIC2_DATA;
        irq -= 8;
    }

    uint8_t mask = inb(port);
    mask |= (uint8_t)(1U << irq);
    outb(port, mask);
}

void pic_send_eoi(uint8_t irq)
{
    if (irq >= 8) {
        outb(PIC2_COMMAND, PIC_EOI);
    }

    outb(PIC1_COMMAND, PIC_EOI);
}