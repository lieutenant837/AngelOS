#include "idt.h"

#define IDT_ENTRIES 256
#define IRQ_VECTOR_BASE 32
#define IRQ_VECTOR_COUNT 16

struct idt_entry {
    uint16_t offset_low;
    uint16_t selector;
    uint8_t ist;
    uint8_t attributes;
    uint16_t offset_middle;
    uint32_t offset_high;
    uint32_t reserved;
} __attribute__((packed));

struct idt_pointer {
    uint16_t limit;
    uint64_t base;
} __attribute__((packed));

static struct idt_entry idt[IDT_ENTRIES];

extern void (*isr_stub_table[48])(void);
extern void isr_default_stub(void);

static void idt_set_gate(
    uint8_t vector,
    void (*handler)(void),
    uint16_t selector
)
{
    uint64_t address = (uint64_t)(uintptr_t)handler;

    idt[vector].offset_low =
        (uint16_t)(address & 0xFFFF);

    idt[vector].selector = selector;
    idt[vector].ist = 0;
    idt[vector].attributes = 0x8E;

    idt[vector].offset_middle =
        (uint16_t)((address >> 16) & 0xFFFF);

    idt[vector].offset_high =
        (uint32_t)((address >> 32) & 0xFFFFFFFF);

    idt[vector].reserved = 0;
}

int idt_init(void)
{
    uint16_t code_selector;

    __asm__ volatile (
        "mov %%cs, %0"
        : "=r"(code_selector)
    );

    /* Initialize every entry with the default handler. */
    for (uint16_t i = 0; i < IDT_ENTRIES; i++) {
        idt_set_gate(
            (uint8_t)i,
            isr_default_stub,
            code_selector
        );
    }

    /* Install CPU exception handlers. */
    for (uint8_t i = 0; i < 32; i++) {
        idt_set_gate(
            i,
            isr_stub_table[i],
            code_selector
        );
    }

    /* Install hardware IRQ handlers at vectors 32-47. */
    for (uint8_t i = 0; i < IRQ_VECTOR_COUNT; i++) {
        idt_set_gate(
            IRQ_VECTOR_BASE + i,
            isr_stub_table[32 + i],
            code_selector
        );
    }

    struct idt_pointer pointer;

    pointer.limit = sizeof(idt) - 1;
    pointer.base = (uint64_t)(uintptr_t)&idt;

    __asm__ volatile (
        "lidt %0"
        :
        : "m"(pointer)
        : "memory"
    );

    return 1;
}