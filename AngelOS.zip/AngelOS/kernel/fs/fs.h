
#ifndef HALOROOT_FS_H
#define HALOROOT_FS_H

#define FS_NAME_MAX 64
#define FS_CONTENT_MAX 512

typedef void (*fs_output_fn)(const char *text);

int fs_init(void);

int fs_create_dir(const char *name);
int fs_create_file(const char *name);
int fs_remove(const char *name);

int fs_change_dir(const char *path);

void fs_list(fs_output_fn output);
void fs_pwd(fs_output_fn output);

int fs_write(const char *name, const char *contents);
const char *fs_read(const char *name);

int fs_getcwd(char *buffer, uint32_t size);

#endif
