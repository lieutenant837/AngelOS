
#include <stdint.h>

#include "fs.h"
#include "../drivers/ata.h"

#define FS_MAX_NODES 128

#define FS_DISK_MAGIC "HALORFS1"
#define FS_DISK_VERSION 1
#define FS_DISK_SECTORS (1 + FS_MAX_NODES * 2)

#define FS_HEADER_LBA 0
#define FS_NODE_LBA(i) (1 + ((uint32_t)(i) * 2))

struct fs_node {
    char name[FS_NAME_MAX];
    char contents[FS_CONTENT_MAX];
    int parent;
    int used;
    int is_directory;
};

static struct fs_node nodes[FS_MAX_NODES];
static int current_directory = 0;

static uint8_t disk_sector[512];

static unsigned int fs_strlen(const char *s)
{
    unsigned int n = 0;

    while (s[n])
        n++;

    return n;
}

static int fs_equals(const char *a, const char *b)
{
    while (*a && *b) {
        if (*a != *b)
            return 0;

        a++;
        b++;
    }

    return *a == *b;
}

static void fs_copy(char *dest, const char *src, unsigned int max)
{
    unsigned int i = 0;

    if (max == 0)
        return;

    while (src[i] && i < max - 1) {
        dest[i] = src[i];
        i++;
    }

    dest[i] = '\0';
}

static void fs_zero_nodes(void)
{
    for (int i = 0; i < FS_MAX_NODES; i++) {
        nodes[i].used = 0;
        nodes[i].is_directory = 0;
        nodes[i].parent = 0;
        nodes[i].name[0] = '\0';
        nodes[i].contents[0] = '\0';
    }

    nodes[0].used = 1;
    nodes[0].is_directory = 1;
    nodes[0].parent = 0;

    fs_copy(nodes[0].name, "/", FS_NAME_MAX);

    current_directory = 0;
}

static void fs_put_u32(uint8_t *buffer, uint32_t value)
{
    buffer[0] = (uint8_t)value;
    buffer[1] = (uint8_t)(value >> 8);
    buffer[2] = (uint8_t)(value >> 16);
    buffer[3] = (uint8_t)(value >> 24);
}

static uint32_t fs_get_u32(const uint8_t *buffer)
{
    return (uint32_t)buffer[0] |
           ((uint32_t)buffer[1] << 8) |
           ((uint32_t)buffer[2] << 16) |
           ((uint32_t)buffer[3] << 24);
}

static void fs_clear_sector(void)
{
    for (int i = 0; i < 512; i++)
        disk_sector[i] = 0;
}

static int fs_save(void)
{
    if (!ata_is_available())
        return 0;

    /*
     * Save every node.
     *
     * First sector:
     *   name[64]
     *   contents[0..447]
     *
     * Second sector:
     *   contents[448..511]
     *   parent (4 bytes)
     *   used (1 byte)
     *   is_directory (1 byte)
     */

    for (int i = 0; i < FS_MAX_NODES; i++) {
        uint32_t lba = FS_NODE_LBA(i);

        fs_clear_sector();

        for (int j = 0; j < FS_NAME_MAX; j++)
            disk_sector[j] = (uint8_t)nodes[i].name[j];

        for (int j = 0; j < 448; j++)
            disk_sector[64 + j] =
                (uint8_t)nodes[i].contents[j];

        if (!ata_write_sector(lba, disk_sector))
            return 0;

        fs_clear_sector();

        for (int j = 0; j < 64; j++)
            disk_sector[j] =
                (uint8_t)nodes[i].contents[448 + j];

        fs_put_u32(&disk_sector[64],
                   (uint32_t)nodes[i].parent);

        disk_sector[68] = (uint8_t)nodes[i].used;
        disk_sector[69] = (uint8_t)nodes[i].is_directory;

        if (!ata_write_sector(lba + 1, disk_sector))
            return 0;
    }

    /*
     * Write the header last.
     * This prevents an incomplete first-time format
     * from being marked as a valid filesystem.
     */

    fs_clear_sector();

    for (int i = 0; i < 8; i++)
        disk_sector[i] = (uint8_t)FS_DISK_MAGIC[i];

    fs_put_u32(&disk_sector[8], FS_DISK_VERSION);
    fs_put_u32(&disk_sector[12], FS_MAX_NODES);

    if (!ata_write_sector(FS_HEADER_LBA, disk_sector))
        return 0;

    return 1;
}

static int fs_load(void)
{
    if (!ata_read_sector(FS_HEADER_LBA, disk_sector))
        return 0;

    for (int i = 0; i < 8; i++) {
        if (disk_sector[i] != (uint8_t)FS_DISK_MAGIC[i])
            return 0;
    }

    if (fs_get_u32(&disk_sector[8]) != FS_DISK_VERSION)
        return 0;

    if (fs_get_u32(&disk_sector[12]) != FS_MAX_NODES)
        return 0;

    for (int i = 0; i < FS_MAX_NODES; i++) {
        uint32_t lba = FS_NODE_LBA(i);

        if (!ata_read_sector(lba, disk_sector))
            return 0;

        for (int j = 0; j < FS_NAME_MAX; j++)
            nodes[i].name[j] = (char)disk_sector[j];

        for (int j = 0; j < 448; j++)
            nodes[i].contents[j] =
                (char)disk_sector[64 + j];

        if (!ata_read_sector(lba + 1, disk_sector))
            return 0;

        for (int j = 0; j < 64; j++)
            nodes[i].contents[448 + j] =
                (char)disk_sector[j];

        nodes[i].parent =
            (int)fs_get_u32(&disk_sector[64]);

        nodes[i].used = disk_sector[68];
        nodes[i].is_directory = disk_sector[69];

        if (nodes[i].used > 1 ||
            nodes[i].is_directory > 1)
            return 0;

        if (nodes[i].parent < 0 ||
            nodes[i].parent >= FS_MAX_NODES)
            return 0;
    }

    /* Validate the root directory. */
    if (!nodes[0].used ||
        !nodes[0].is_directory ||
        nodes[0].parent != 0)
        return 0;

    /* Validate all used nodes and their parents. */
    for (int i = 1; i < FS_MAX_NODES; i++) {
        if (!nodes[i].used)
            continue;

        if (nodes[i].parent == i)
            return 0;

        if (!nodes[nodes[i].parent].used ||
            !nodes[nodes[i].parent].is_directory)
            return 0;

        int terminated = 0;

        for (int j = 0; j < FS_NAME_MAX; j++) {
            if (nodes[i].name[j] == '\0') {
                terminated = 1;
                break;
            }
        }

        if (!terminated || nodes[i].name[0] == '\0')
            return 0;

        /* Ensure file contents are terminated. */
        if (!nodes[i].is_directory)
            nodes[i].contents[FS_CONTENT_MAX - 1] = '\0';
    }

    current_directory = 0;

    return 1;
}

static int fs_find_child(int parent, const char *name)
{
    for (int i = 1; i < FS_MAX_NODES; i++) {
        if (nodes[i].used &&
            nodes[i].parent == parent &&
            fs_equals(nodes[i].name, name))
            return i;
    }

    return -1;
}

static int fs_allocate_node(void)
{
    for (int i = 1; i < FS_MAX_NODES; i++) {
        if (!nodes[i].used)
            return i;
    }

    return -1;
}

static int fs_resolve(const char *path)
{
    if (!path || !path[0])
        return -1;

    int directory = path[0] == '/' ? 0 : current_directory;
    unsigned int position = 0;

    while (path[position] == '/')
        position++;

    while (path[position]) {
        char component[FS_NAME_MAX];
        unsigned int length = 0;

        while (path[position] && path[position] != '/') {
            if (length >= FS_NAME_MAX - 1)
                return -1;

            component[length++] = path[position++];
        }

        component[length] = '\0';

        while (path[position] == '/')
            position++;

        if (length == 0)
            continue;

        if (fs_equals(component, "."))
            continue;

        if (fs_equals(component, "..")) {
            if (directory != 0)
                directory = nodes[directory].parent;

            continue;
        }

        int next = fs_find_child(directory, component);

        if (next < 0)
            return -1;

        if (!nodes[next].is_directory && path[position])
            return -1;

        directory = next;
    }

    return directory;
}

static int fs_valid_name(const char *name)
{
    if (!name || !name[0])
        return 0;

    unsigned int length = fs_strlen(name);

    if (length >= FS_NAME_MAX)
        return 0;

    if (fs_equals(name, ".") || fs_equals(name, ".."))
        return 0;

    for (unsigned int i = 0; i < length; i++) {
        if (name[i] == '/' || name[i] == '\\')
            return 0;
    }

    return 1;
}

static int fs_create_node(const char *path, int is_directory)
{
    if (!path || !path[0])
        return 0;

    char parent_path[FS_CONTENT_MAX];
    char name[FS_NAME_MAX];
    unsigned int length = fs_strlen(path);

    if (length >= FS_CONTENT_MAX)
        return 0;

    int parent = current_directory;
    int last_slash = -1;

    for (unsigned int i = 0; i < length; i++) {
        if (path[i] == '/')
            last_slash = (int)i;
    }

    if (last_slash >= 0) {
        unsigned int name_start = (unsigned int)last_slash + 1;
        unsigned int name_length = length - name_start;

        if (name_length == 0 || name_length >= FS_NAME_MAX)
            return 0;

        for (unsigned int i = 0; i < name_length; i++)
            name[i] = path[name_start + i];
        name[name_length] = '\0';

        if (last_slash == 0) {
            fs_copy(parent_path, "/", sizeof(parent_path));
        } else {
            for (int i = 0; i < last_slash; i++)
                parent_path[i] = path[i];
            parent_path[last_slash] = '\0';
        }

        parent = fs_resolve(parent_path);
        if (parent < 0)
            return 0;
    } else {
        if (length >= FS_NAME_MAX)
            return 0;
        fs_copy(name, path, sizeof(name));
    }

    if (!fs_valid_name(name) ||
        parent < 0 ||
        !nodes[parent].used ||
        !nodes[parent].is_directory)
        return 0;

    if (fs_find_child(parent, name) >= 0)
        return 0;

    int index = fs_allocate_node();
    if (index < 0)
        return 0;

    nodes[index].used = 1;
    nodes[index].is_directory = is_directory;
    nodes[index].parent = parent;
    fs_copy(nodes[index].name, name, FS_NAME_MAX);
    nodes[index].contents[0] = '\0';

    if (!fs_save()) {
        nodes[index].used = 0;
        nodes[index].name[0] = '\0';
        nodes[index].contents[0] = '\0';
        return 0;
    }

    return 1;
}

int fs_init(void)
{
    /* Initialize the primary master ATA disk. */
    if (!ata_init())
        return 0;

    if (!ata_is_available())
        return 0;

    /* Ensure the disk is large enough for this filesystem. */
    if (ata_get_sector_count() < FS_DISK_SECTORS)
        return 0;

    /* Load an existing filesystem if one is present. */
    if (fs_load())
        return 1;

    /*
     * No valid filesystem was found.
     * Initialize the dedicated virtual disk.
     */
    fs_zero_nodes();

    if (!fs_save())
        return 0;

    return 1;
}

int fs_create_dir(const char *name)
{
    return fs_create_node(name, 1);
}

int fs_create_file(const char *name)
{
    return fs_create_node(name, 0);
}

int fs_change_dir(const char *path)
{
    int target = fs_resolve(path);

    if (target < 0 || !nodes[target].is_directory)
        return 0;

    current_directory = target;
    return 1;
}

void fs_list(fs_output_fn output)
{
    if (!output)
        return;

    int found = 0;

    output("\n");

    for (int i = 1; i < FS_MAX_NODES; i++) {
        if (!nodes[i].used ||
            nodes[i].parent != current_directory)
            continue;

        found = 1;

        if (nodes[i].is_directory) {
            output("[DIR]  ");
            output(nodes[i].name);
            output("/\n");
        } else {
            output("[FILE] ");
            output(nodes[i].name);
            output("\n");
        }
    }

    if (!found)
        output("(This directory is empty.)\n");

    output("\n");
}

int fs_getcwd(char *buffer, uint32_t size)
{
    if (!buffer || size < 2 ||
        current_directory < 0 ||
        current_directory >= FS_MAX_NODES)
        return 0;

    int stack[FS_MAX_NODES];
    int count = 0;
    int directory = current_directory;

    while (directory != 0 && count < FS_MAX_NODES) {
        if (!nodes[directory].used ||
            !nodes[directory].is_directory)
            return 0;

        stack[count++] = directory;
        directory = nodes[directory].parent;
    }

    uint32_t position = 0;
    buffer[position++] = '/';

    while (count > 0) {
        const char *name = nodes[stack[--count]].name;
        unsigned int length = fs_strlen(name);

        if (position + length + (count ? 1U : 0U) >= size)
            return 0;

        for (unsigned int i = 0; i < length; i++)
            buffer[position++] = name[i];

        if (count > 0)
            buffer[position++] = '/';
    }

    buffer[position] = '\0';
    return 1;
}

void fs_pwd(fs_output_fn output)
{
    if (!output)
        return;

    char path[FS_CONTENT_MAX];

    if (!fs_getcwd(path, sizeof(path))) {
        output("[path unavailable]\\n");
        return;
    }

    output(path);
    output("\\n");
}

int fs_remove(const char *name)
{
    int index = fs_resolve(name);

    if (index <= 0)
        return 0;

    if (nodes[index].is_directory) {
        for (int i = 1; i < FS_MAX_NODES; i++) {
            if (nodes[i].used && nodes[i].parent == index)
                return 0;
        }
    }

    struct fs_node old_node = nodes[index];

    nodes[index].used = 0;
    nodes[index].name[0] = '\0';
    nodes[index].contents[0] = '\0';

    if (!fs_save()) {
        nodes[index] = old_node;
        return 0;
    }

    return 1;
}

int fs_write(const char *name, const char *contents)
{
    if (!name || !contents)
        return 0;

    int index = fs_resolve(name);

    if (index < 0 || nodes[index].is_directory)
        return 0;

    if (fs_strlen(contents) >= FS_CONTENT_MAX)
        return 0;

    char old_contents[FS_CONTENT_MAX];

    fs_copy(old_contents, nodes[index].contents, FS_CONTENT_MAX);
    fs_copy(nodes[index].contents, contents, FS_CONTENT_MAX);

    if (!fs_save()) {
        fs_copy(nodes[index].contents,
                old_contents,
                FS_CONTENT_MAX);
        return 0;
    }

    return 1;
}

const char *fs_read(const char *name)
{
    if (!name)
        return 0;

    int index = fs_resolve(name);

    if (index < 0 || nodes[index].is_directory)
        return 0;

    return nodes[index].contents;
}
