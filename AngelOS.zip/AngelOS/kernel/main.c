#include <stdint.h>

#include "memory/pmm.h"
#include "memory/vmm.h"
#include "memory/heap.h"
#include "interrupts/interrupts.h"
#include "interrupts/pic.h"
#include "drivers/pit.h"
#include "drivers/keyboard.h"
#include "drivers/rtc.h"
#include "drivers/ata.h"
#include "fs/fs.h"

extern char __kernel_start[];
extern char __kernel_end[];

#define COM1 0x3F8

#define SHELL_INPUT_SIZE 128
#define SHELL_HISTORY_SIZE 16
#define SHELL_ALIAS_COUNT 8
#define SHELL_ALIAS_NAME_SIZE 32
#define SHELL_MAX_ARGUMENTS 16

/* =========================================
   SERIAL DRIVER
   ========================================= */

static inline void outb(uint16_t port, uint8_t value)
{
    __asm__ volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
}

static inline uint8_t inb(uint16_t port)
{
    uint8_t value;
    __asm__ volatile ("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static inline void outw(uint16_t port, uint16_t value)
{
    __asm__ volatile ("outw %0, %1" : : "a"(value), "Nd"(port));
}

static inline uint16_t inw(uint16_t port)
{
    uint16_t value;
    __asm__ volatile ("inw %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static void serial_init(void)
{
    outb(COM1 + 1, 0x00);
    outb(COM1 + 3, 0x80);
    outb(COM1 + 0, 0x03);
    outb(COM1 + 1, 0x00);
    outb(COM1 + 3, 0x03);
    outb(COM1 + 2, 0xC7);
    outb(COM1 + 4, 0x0B);
}

void serial_write_char(char c)
{
    while ((inb(COM1 + 5) & 0x20) == 0)
        __asm__ volatile ("pause");

    outb(COM1, (uint8_t)c);
}

void serial_write(const char *text)
{
    while (*text)
        serial_write_char(*text++);
}

void serial_write_hex(uint64_t value)
{
    static const char digits[] = "0123456789ABCDEF";

    serial_write("0x");

    for (int i = 60; i >= 0; i -= 4)
        serial_write_char(digits[(value >> i) & 0xF]);
}

static void serial_write_number(uint64_t value)
{
    char buffer[21];
    uint32_t position = 0;

    if (value == 0) {
        serial_write_char('0');
        return;
    }

    while (value > 0 && position < sizeof(buffer)) {
        buffer[position++] = '0' + (value % 10);
        value /= 10;
    }

    while (position > 0)
        serial_write_char(buffer[--position]);
}

static void kernel_halt(void)
{
    for (;;) {
        __asm__ volatile ("cli; hlt");
    }
}

/* =========================================
   LIMINE REQUESTS
   ========================================= */

struct limine_rsdp_response {
    uint64_t revision;
    uint64_t address;
};

struct limine_rsdp_request {
    uint64_t id[4];
    uint64_t revision;
    struct limine_rsdp_response *response;
};

__attribute__((used, section(".limine_requests_start"), aligned(8)))
static volatile uint64_t limine_start_marker[] = {
    0xf6b8f4b39de7d1ae,
    0xfab91a6940fcb9cf,
    0x785c6ed015d3e316,
    0x181e920a7852b9d9
};

__attribute__((used, section(".limine_requests"), aligned(8)))
static volatile uint64_t limine_base_revision[] = {
    0xf9562b2d5c95a6c8,
    0x6a7b384944536bdc,
    3
};

__attribute__((used, section(".limine_requests"), aligned(8)))
static volatile struct limine_memmap_request memmap_request = {
    .id = {
        0xc7b1dd30df4c8b88,
        0x0a82e883a194f07b,
        0x67cf3d9d378a806f,
        0xe304acdfc50c3c62
    },
    .revision = 0,
    .response = 0
};

__attribute__((used, section(".limine_requests"), aligned(8)))
static volatile struct limine_kernel_address_request kernel_address_request = {
    .id = {
        0xc7b1dd30df4c8b88,
        0x0a82e883a194f07b,
        0x71ba76863cc55f63,
        0xb2644a48c516a487
    },
    .revision = 0,
    .response = 0
};

__attribute__((used, section(".limine_requests"), aligned(8)))
static volatile struct limine_hhdm_request hhdm_request = {
    .id = {
        0xc7b1dd30df4c8b88,
        0x0a82e883a194f07b,
        0x48dcf1cb8ad2b852,
        0x63984e959a98244b
    },
    .revision = 0,
    .response = 0
};

__attribute__((used, section(".limine_requests"), aligned(8)))
static volatile struct limine_rsdp_request rsdp_request = {
    .id = {
        0xc7b1dd30df4c8b88,
        0x0a82e883a194f07b,
        0xc5e77b6b397e7b43,
        0x27637845accdcf3c
    },
    .revision = 0,
    .response = 0
};

__attribute__((used, section(".limine_requests_end"), aligned(8)))
static volatile uint64_t limine_end_marker[] = {
    0xadc0e0531bb10d03,
    0x9572709f31764c62
};

/* =========================================
   SHELL STRING UTILITIES
   ========================================= */

static int shell_equals(const char *a, const char *b)
{
    while (*a && *b) {
        if (*a != *b)
            return 0;
        a++;
        b++;
    }

    return *a == '\0' && *b == '\0';
}

static int shell_starts_with(const char *text, const char *prefix)
{
    while (*prefix) {
        if (*text != *prefix)
            return 0;
        text++;
        prefix++;
    }

    return 1;
}

static uint64_t shell_string_length(const char *text)
{
    uint64_t length = 0;

    while (text[length])
        length++;

    return length;
}

static void shell_string_copy(char *destination, const char *source)
{
    uint64_t i = 0;

    while (source[i] && i < SHELL_INPUT_SIZE - 1) {
        destination[i] = source[i];
        i++;
    }

    destination[i] = '\0';
}

static void shell_print_prompt(void)
{
    serial_write("angel> ");
}

/* =========================================
   COMMAND HISTORY
   ========================================= */

static char command_history[SHELL_HISTORY_SIZE][SHELL_INPUT_SIZE];
static uint32_t history_count = 0;
static uint32_t history_position = 0;
static char history_draft[SHELL_INPUT_SIZE];

static void shell_history_save(const char *command)
{
    if (!command[0])
        return;

    if (history_count > 0 &&
        shell_equals(command_history[history_count - 1], command))
        return;

    if (history_count == SHELL_HISTORY_SIZE) {
        for (uint32_t i = 1; i < SHELL_HISTORY_SIZE; i++)
            shell_string_copy(command_history[i - 1], command_history[i]);

        history_count--;
    }

    shell_string_copy(command_history[history_count], command);
    history_count++;
}

static void shell_history_up(char *line)
{
    if (history_count == 0 || history_position == 0)
        return;

    if (history_position == history_count)
        shell_string_copy(history_draft, line);

    history_position--;
    shell_string_copy(line, command_history[history_position]);
}

static void shell_history_down(char *line)
{
    if (history_position >= history_count)
        return;

    history_position++;

    if (history_position == history_count)
        shell_string_copy(line, history_draft);
    else
        shell_string_copy(line, command_history[history_position]);
}

/* =========================================
   TERMINAL LINE EDITOR
   ========================================= */

static void shell_print_cursor_left(uint64_t count)
{
    if (count == 0)
        return;

    serial_write("\033[");
    serial_write_number(count);
    serial_write("D");
}

static void shell_redraw_line(
    const char *line,
    uint64_t length,
    uint64_t cursor
)
{
    serial_write("\r");
    shell_print_prompt();

    for (uint64_t i = 0; i < length; i++)
        serial_write_char(line[i]);

    serial_write("\033[K");
    shell_print_cursor_left(length - cursor);
}

static void shell_insert_character(
    char *line,
    uint64_t *length,
    uint64_t *cursor,
    char character
)
{
    if (*length >= SHELL_INPUT_SIZE - 1)
        return;

    for (uint64_t i = *length; i > *cursor; i--)
        line[i] = line[i - 1];

    line[*cursor] = character;
    (*length)++;
    (*cursor)++;
    line[*length] = '\0';

    shell_redraw_line(line, *length, *cursor);
}

static void shell_backspace(
    char *line,
    uint64_t *length,
    uint64_t *cursor
)
{
    if (*cursor == 0)
        return;

    for (uint64_t i = *cursor; i < *length; i++)
        line[i - 1] = line[i];

    (*cursor)--;
    (*length)--;
    line[*length] = '\0';

    shell_redraw_line(line, *length, *cursor);
}

static void shell_delete(
    char *line,
    uint64_t *length,
    uint64_t cursor
)
{
    if (cursor >= *length)
        return;

    for (uint64_t i = cursor; i < *length; i++)
        line[i] = line[i + 1];

    (*length)--;

    shell_redraw_line(line, *length, cursor);
}

/* =========================================
   TAB COMPLETION
   ========================================= */

static const char *shell_commands[] = {
    "help", "clear", "info", "version", "uptime",
    "date", "time", "memory", "echo", "alias",
    "unalias", "reboot", "shutdown",
    "crdir", "list", "sdir", "crf", "src",
    "write", "rm", "pwd", "disk", "diskread"
};

#define SHELL_COMMAND_COUNT \
    (sizeof(shell_commands) / sizeof(shell_commands[0]))

static void shell_tab_complete(
    char *line,
    uint64_t *length,
    uint64_t *cursor
)
{
    for (uint64_t i = 0; i < *cursor; i++) {
        if (line[i] == ' ' || line[i] == '\t')
            return;
    }

    const char *match = 0;
    uint32_t matches = 0;

    for (uint32_t i = 0; i < SHELL_COMMAND_COUNT; i++) {
        if (shell_starts_with(shell_commands[i], line)) {
            match = shell_commands[i];
            matches++;
        }
    }

    if (matches == 0)
        return;

    if (matches == 1) {
        uint64_t command_length = shell_string_length(match);

        if (command_length >= SHELL_INPUT_SIZE - 1)
            return;

        for (uint64_t i = 0; i < command_length; i++)
            line[i] = match[i];

        *length = command_length;
        *cursor = command_length;

        if (*length < SHELL_INPUT_SIZE - 1) {
            line[*length] = ' ';
            (*length)++;
            (*cursor)++;
        }

        line[*length] = '\0';
        shell_redraw_line(line, *length, *cursor);
        return;
    }

    serial_write("\r\n");

    for (uint32_t i = 0; i < SHELL_COMMAND_COUNT; i++) {
        if (shell_starts_with(shell_commands[i], line)) {
            serial_write(shell_commands[i]);
            serial_write("    ");
        }
    }

    serial_write("\r\n");
    shell_redraw_line(line, *length, *cursor);
}

/* =========================================
   SHELL COMMANDS
   ========================================= */

static void shell_fs_commands_help(void);

static void shell_help(void)
{
    serial_write("\n");
    serial_write("========== AngelOS Shell 1.6 ==========\n\n");
    serial_write("help       - Show available commands\n");
    serial_write("clear      - Clear terminal\n");
    serial_write("info       - System information\n");
    serial_write("version    - Show version\n");
    serial_write("uptime     - Show system uptime\n");
    serial_write("date       - Show hardware date\n");
    serial_write("time       - Show hardware time\n");
    serial_write("memory     - Show memory statistics\n");
    serial_write("echo       - Print text\n");
    serial_write("alias      - Create/list aliases\n");
    serial_write("unalias    - Remove an alias\n");
    serial_write("reboot     - Restart AngelOS\n");
    serial_write("shutdown   - Shut down using ACPI\n");

    serial_write("\nFilesystem commands:\n");
    shell_fs_commands_help();
    serial_write("\nDisk commands:\n");
    serial_write("disk                 - List detected ATA disks\n");
    serial_write("diskread <dev> <lba> - Read and hex-dump one sector\n");

    serial_write("\nKeyboard shortcuts:\n");
    serial_write("UP/DOWN    - Command history\n");
    serial_write("LEFT/RIGHT - Move cursor\n");
    serial_write("HOME/END   - Move to line beginning/end\n");
    serial_write("DELETE     - Delete character\n");
    serial_write("TAB        - Complete command\n");
    serial_write("\n========================================\n\n");
}

static void shell_info(void)
{
    serial_write("\n");
    serial_write("====================================\n");
    serial_write("             AngelOS                \n");
    serial_write("====================================\n");
    serial_write("Operating System: AngelOS\n");
    serial_write("Kernel: HaloRoot\n");
    serial_write("Version: 1.6\n");
    serial_write("Architecture: x86-64\n");
    serial_write("Bootloader: Limine\n");
    serial_write("Terminal: AngelOS Shell\n");
    serial_write("Filesystem: ATA disk-backed filesystem\n");
    serial_write("Disk driver: ATA PIO\n");
    serial_write("====================================\n\n");
}

static void shell_version(void)
{
    serial_write("\nAngelOS 1.6\n");
    serial_write("HaloRoot Kernel 1.6\n\n");
}

static void shell_uptime(void)
{
    uint64_t ticks = pit_get_ticks();

    serial_write("\nSystem uptime: ");
    serial_write_number(ticks / 100);
    serial_write(" seconds\n\n");
}

static void shell_date(void)
{
    struct rtc_datetime dt;

    if (!rtc_get_datetime(&dt)) {
        serial_write("\n[RTC] Unable to read hardware date.\n\n");
        return;
    }

    serial_write("\nDate: ");
    serial_write_number(dt.year);
    serial_write_char('-');

    if (dt.month < 10)
        serial_write_char('0');

    serial_write_number(dt.month);
    serial_write_char('-');

    if (dt.day < 10)
        serial_write_char('0');

    serial_write_number(dt.day);
    serial_write("\n\n");
}

static void shell_time(void)
{
    struct rtc_datetime dt;

    if (!rtc_get_datetime(&dt)) {
        serial_write("\n[RTC] Unable to read hardware time.\n\n");
        return;
    }

    serial_write("\nTime: ");

    if (dt.hour < 10)
        serial_write_char('0');

    serial_write_number(dt.hour);
    serial_write_char(':');

    if (dt.minute < 10)
        serial_write_char('0');

    serial_write_number(dt.minute);
    serial_write_char(':');

    if (dt.second < 10)
        serial_write_char('0');

    serial_write_number(dt.second);
    serial_write("\n\n");
}

static void shell_memory(void)
{
    serial_write("\n========== PHYSICAL MEMORY ==========\n");

    serial_write("Total managed pages: ");
    serial_write_hex(pmm_get_total_pages());
    serial_write("\n");

    serial_write("Used pages:          ");
    serial_write_hex(pmm_get_used_pages());
    serial_write("\n");

    serial_write("Free pages:          ");
    serial_write_hex(pmm_get_free_pages());
    serial_write("\n");

    serial_write("Allocations:         ");
    serial_write_hex(pmm_get_allocation_count());
    serial_write("\n");

    serial_write("Releases:            ");
    serial_write_hex(pmm_get_release_count());
    serial_write("\n");

    serial_write("\n============= KERNEL HEAP ===========\n");

    serial_write("Heap pages:          ");
    serial_write_hex(heap_get_page_count());
    serial_write("\n");

    serial_write("Free blocks:         ");
    serial_write_hex(heap_get_free_block_count());
    serial_write("\n");

    serial_write("=====================================\n\n");
}

static void shell_clear(void)
{
    serial_write("\033[2J\033[H");
}

/* =========================================
   ALIASES
   ========================================= */

struct shell_alias {
    char name[SHELL_ALIAS_NAME_SIZE];
    char command[SHELL_INPUT_SIZE];
};

static struct shell_alias aliases[SHELL_ALIAS_COUNT];
static uint32_t alias_count = 0;

static int shell_find_alias(const char *name)
{
    for (uint32_t i = 0; i < alias_count; i++) {
        if (shell_equals(aliases[i].name, name))
            return (int)i;
    }

    return -1;
}

static void shell_list_aliases(void)
{
    serial_write("\n========== ALIASES ==========\n");

    if (alias_count == 0)
        serial_write("No aliases defined.\n");

    for (uint32_t i = 0; i < alias_count; i++) {
        serial_write(aliases[i].name);
        serial_write(" = ");
        serial_write(aliases[i].command);
        serial_write("\n");
    }

    serial_write("=============================\n\n");
}

static void shell_create_alias(const char *name, const char *command)
{
    if (!name || !*name || !command || !*command) {
        serial_write("\nUsage: alias name=command\n\n");
        return;
    }

    uint32_t name_length = 0;

    while (name[name_length]) {
        char c = name[name_length];

        if (!((c >= 'a' && c <= 'z') ||
              (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9') ||
              c == '_' || c == '-')) {
            serial_write("\nInvalid alias name.\n\n");
            return;
        }

        name_length++;

        if (name_length >= SHELL_ALIAS_NAME_SIZE) {
            serial_write("\nAlias name too long.\n\n");
            return;
        }
    }

    int index = shell_find_alias(name);

    if (index < 0) {
        if (alias_count >= SHELL_ALIAS_COUNT) {
            serial_write("\nMaximum aliases reached.\n\n");
            return;
        }

        index = (int)alias_count++;
    }

    for (uint32_t i = 0; i <= name_length; i++)
        aliases[index].name[i] = name[i];

    shell_string_copy(aliases[index].command, command);

    serial_write("\nAlias created: ");
    serial_write(name);
    serial_write(" = ");
    serial_write(aliases[index].command);
    serial_write("\n\n");
}

static void shell_remove_alias(const char *name)
{
    int index = shell_find_alias(name);

    if (index < 0) {
        serial_write("\nAlias not found.\n\n");
        return;
    }

    for (uint32_t i = (uint32_t)index; i + 1 < alias_count; i++)
        aliases[i] = aliases[i + 1];

    alias_count--;

    serial_write("\nAlias removed.\n\n");
}

/* =========================================
   ARGUMENT PARSER
   ========================================= */

static int shell_parse_arguments(
    char *text,
    char *argv[],
    int capacity
)
{
    int argc = 0;
    char *read = text;
    char *write = text;

    while (*read && argc < capacity) {
        while (*read == ' ' || *read == '\t')
            read++;

        if (!*read)
            break;

        argv[argc++] = write;

        char quote = 0;

        while (*read) {
            char c = *read++;

            if (quote) {
                if (c == quote) {
                    quote = 0;
                } else if (c == '\\' && *read == quote) {
                    *write++ = *read++;
                } else {
                    *write++ = c;
                }
            } else if (c == '"' || c == '\'') {
                quote = c;
            } else if (c == ' ' || c == '\t') {
                break;
            } else {
                *write++ = c;
            }
        }

        while (*read == ' ' || *read == '\t')
            read++;

        *write++ = '\0';
    }

    return argc;
}

/* =========================================
   FILESYSTEM COMMANDS
   ========================================= */

static void shell_fs_commands_help(void)
{
    serial_write("crdir <name>        - Create a directory\n");
    serial_write("list                - List current directory\n");
    serial_write("sdir <path>         - Change directory\n");
    serial_write("crf <name>          - Create a file\n");
    serial_write("src <name>          - Display file contents\n");
    serial_write("write <name> <text> - Write text to a file\n");
    serial_write("rm <name>           - Remove file or empty directory\n");
    serial_write("pwd                 - Show current directory\n");
}

static void shell_fs_create_dir(const char *name)
{
    if (!name || !name[0]) {
        serial_write("\nUsage: crdir <name>\n\n");
        return;
    }

    if (fs_create_dir(name)) {
        serial_write("\n[FS] Directory created: ");
        serial_write(name);
        serial_write("\n\n");
    } else {
        serial_write("\n[FS] Could not create directory.\n");
        serial_write("[FS] It may already exist or the filesystem may be full.\n\n");
    }
}

static void shell_fs_create_file(const char *name)
{
    if (!name || !name[0]) {
        serial_write("\nUsage: crf <name>\n\n");
        return;
    }

    if (fs_create_file(name)) {
        serial_write("\n[FS] File created: ");
        serial_write(name);
        serial_write("\n\n");
    } else {
        serial_write("\n[FS] Could not create file.\n");
        serial_write("[FS] It may already exist or the filesystem may be full.\n\n");
    }
}

static void shell_fs_change_dir(const char *path)
{
    if (!path || !path[0]) {
        serial_write("\nUsage: sdir <path>\n\n");
        return;
    }

    if (fs_change_dir(path)) {
        serial_write("\n[FS] Current directory changed.\n\n");
    } else {
        serial_write("\n[FS] Directory not found.\n\n");
    }
}

static void shell_fs_read(const char *name)
{
    if (!name || !name[0]) {
        serial_write("\nUsage: src <filename>\n\n");
        return;
    }

    const char *contents = fs_read(name);

    if (!contents) {
        serial_write("\n[FS] File not found.\n\n");
        return;
    }

    serial_write("\n");

    if (!contents[0])
        serial_write("[Empty file]\n");
    else {
        serial_write(contents);

        if (contents[shell_string_length(contents) - 1] != '\n')
            serial_write("\n");
    }

    serial_write("\n");
}

static void shell_fs_write(const char *name, const char *contents)
{
    if (!name || !name[0] || !contents) {
        serial_write("\nUsage: write <filename> <text>\n\n");
        return;
    }

    if (fs_write(name, contents)) {
        serial_write("\n[FS] File written successfully.\n\n");
    } else {
        serial_write("\n[FS] Could not write to file.\n");
        serial_write("[FS] Check that the file exists and the content fits.\n\n");
    }
}

static void shell_fs_remove(const char *name)
{
    if (!name || !name[0]) {
        serial_write("\nUsage: rm <name>\n\n");
        return;
    }

    if (fs_remove(name)) {
        serial_write("\n[FS] Removed: ");
        serial_write(name);
        serial_write("\n\n");
    } else {
        serial_write("\n[FS] Could not remove item.\n");
        serial_write("[FS] It may not exist, or the directory may not be empty.\n\n");
    }
}

static void shell_fs_list_output(const char *text)
{
    serial_write(text);
}

static void shell_fs_pwd_output(const char *text)
{
    serial_write(text);
}

/* =========================================
   ATA DISK SHELL COMMANDS
   ========================================= */

static int shell_parse_u32(const char *text, uint32_t *value)
{
    if (!text || !text[0] || !value)
        return 0;

    uint32_t result = 0;

    for (uint32_t i = 0; text[i]; i++) {
        if (text[i] < '0' || text[i] > '9')
            return 0;

        uint32_t digit = (uint32_t)(text[i] - '0');

        if (result > (UINT32_MAX - digit) / 10)
            return 0;

        result = result * 10 + digit;
    }

    *value = result;
    return 1;
}

static void serial_write_hex_byte(uint8_t value)
{
    static const char digits[] = "0123456789ABCDEF";
    serial_write_char(digits[(value >> 4) & 0x0F]);
    serial_write_char(digits[value & 0x0F]);
}

static void shell_disk_list(void)
{
    uint32_t count = ata_get_device_count();

    serial_write("\n========== ATA DISKS ==========\n");

    if (count == 0) {
        serial_write("No supported ATA disks detected.\n");
        serial_write("This driver requires a legacy IDE-compatible controller.\n");
        serial_write("===============================\n\n");
        return;
    }

    for (uint32_t i = 0; i < count; i++) {
        const struct ata_device_info *device = ata_get_device(i);

        if (!device)
            continue;

        serial_write("Device ");
        serial_write_number(i);
        serial_write(": ");

        if (device->channel == 0)
            serial_write("Primary ");
        else
            serial_write("Secondary ");

        serial_write(device->drive == 0 ? "Master\n" : "Slave\n");
        serial_write("  Model: ");
        serial_write(device->model);
        serial_write("\n  Sectors (LBA28): ");
        serial_write_number(device->sectors);
        serial_write("\n  Capacity: ");
        serial_write_number(device->sectors / 2048);
        serial_write(" MiB\n");
    }

    serial_write("===============================\n\n");
}

static void shell_disk_read(uint32_t device_index, uint32_t lba)
{
    const struct ata_device_info *device = ata_get_device(device_index);

    if (!device) {
        serial_write("\n[ATA] Invalid device index. Use 'disk' to list disks.\n\n");
        return;
    }

    if (lba >= device->sectors || lba >= 0x10000000U) {
        serial_write("\n[ATA] LBA is outside the supported disk range.\n\n");
        return;
    }

    uint16_t sector[256];

    serial_write("\n[ATA] Reading device ");
    serial_write_number(device_index);
    serial_write(", LBA ");
    serial_write_number(lba);
    serial_write("...\n");

    if (!ata_read_sector_device((uint8_t)device_index, lba, sector)) {
        serial_write("[ATA] Sector read failed.\n\n");
        return;
    }

    const uint8_t *bytes = (const uint8_t *)sector;

    for (uint32_t offset = 0; offset < 512; offset += 16) {
        serial_write("  ");
        serial_write_number(offset);
        serial_write(": ");

        for (uint32_t i = 0; i < 16; i++) {
            serial_write_hex_byte(bytes[offset + i]);
            serial_write_char(' ');
        }

        serial_write("\n");
    }

    serial_write("[ATA] Sector read completed (read-only).\n\n");
}

/* =========================================
   ACPI SUPPORT
   ========================================= */

struct acpi_rsdp {
    char signature[8];
    uint8_t checksum;
    char oem_id[6];
    uint8_t revision;
    uint32_t rsdt_address;
    uint32_t length;
    uint64_t xsdt_address;
    uint8_t extended_checksum;
    uint8_t reserved[3];
} __attribute__((packed));

struct acpi_sdt_header {
    char signature[4];
    uint32_t length;
    uint8_t revision;
    uint8_t checksum;
    char oem_id[6];
    char oem_table_id[8];
    uint32_t oem_revision;
    uint32_t creator_id;
    uint32_t creator_revision;
} __attribute__((packed));

struct acpi_gas {
    uint8_t address_space;
    uint8_t bit_width;
    uint8_t bit_offset;
    uint8_t access_size;
    uint64_t address;
} __attribute__((packed));

struct acpi_register {
    uint8_t address_space;
    uint64_t address;
    uint8_t bit_width;
};

#define ACPI_SPACE_MEMORY 0
#define ACPI_SPACE_IO     1

#define ACPI_SLP_TYP_SHIFT 10
#define ACPI_SLP_TYP_MASK  (7 << ACPI_SLP_TYP_SHIFT)
#define ACPI_SLP_EN        (1 << 13)
#define ACPI_SCI_EN        1

static uint64_t acpi_hhdm = 0;

static uint8_t acpi_read8(const void *pointer, uint64_t offset)
{
    const volatile uint8_t *p = (const volatile uint8_t *)pointer;
    return p[offset];
}

static uint32_t acpi_read32(const void *pointer, uint64_t offset)
{
    uint32_t value = 0;

    for (uint32_t i = 0; i < 4; i++)
        value |= (uint32_t)acpi_read8(pointer, offset + i) << (i * 8);

    return value;
}

static uint64_t acpi_read64(const void *pointer, uint64_t offset)
{
    uint64_t value = 0;

    for (uint32_t i = 0; i < 8; i++)
        value |= (uint64_t)acpi_read8(pointer, offset + i) << (i * 8);

    return value;
}

/*
 * Map every 4 KiB page covered by a physical memory range.
 * ACPI tables can cross page boundaries, so mapping only
 * the first page is not sufficient.
 */
static int acpi_map_physical_range(uint64_t physical, uint64_t length)
{
    if (physical == 0 || length == 0)
        return 0;

    if (physical > UINT64_MAX - (length - 1))
        return 0;

    if (physical > UINTPTR_MAX - acpi_hhdm)
        return 0;

    uintptr_t virtual_start =
        (uintptr_t)(acpi_hhdm + physical);

    if (length - 1 > UINTPTR_MAX - virtual_start)
        return 0;

    uint64_t first_page = physical & ~(4096ULL - 1);
    uint64_t last_address = physical + length - 1;
    uint64_t last_page = last_address & ~(4096ULL - 1);

    for (uint64_t page = first_page;; page += 4096) {
        if (!vmm_map_hhdm_page(page)) {
            serial_write("[ACPI] Failed to map physical page: ");
            serial_write_hex(page);
            serial_write("\n");
            return 0;
        }

        if (page == last_page)
            break;

        if (page > UINT64_MAX - 4096)
            return 0;
    }

    return 1;
}

static void *acpi_physical_to_virtual(uint64_t physical)
{
    if (physical == 0)
        return 0;

    if (!acpi_map_physical_range(physical, 1))
        return 0;

    return (void *)(uintptr_t)(acpi_hhdm + physical);
}

static int acpi_checksum(const void *data, uint32_t length)
{
    const volatile uint8_t *bytes = (const volatile uint8_t *)data;
    uint8_t sum = 0;

    for (uint32_t i = 0; i < length; i++)
        sum = (uint8_t)(sum + bytes[i]);

    return sum == 0;
}

static int acpi_signature_matches(
    const void *data,
    const char *signature,
    uint32_t length
)
{
    const volatile char *bytes = (const volatile char *)data;

    for (uint32_t i = 0; i < length; i++) {
        if (bytes[i] != signature[i])
            return 0;
    }

    return 1;
}

/* =========================================
   ACPI RSDP
   ========================================= */

static struct acpi_rsdp *acpi_find_rsdp(void)
{
    acpi_hhdm = vmm_get_hhdm_offset();

    if (!rsdp_request.response) {
        serial_write("[ACPI] Limine did not provide an RSDP response.\n");
        return 0;
    }

    uint64_t physical_address = rsdp_request.response->address;

    if (physical_address == 0) {
        serial_write("[ACPI] Limine returned a null RSDP address.\n");
        return 0;
    }

    serial_write("[ACPI] Limine RSDP physical address: ");
    serial_write_hex(physical_address);
    serial_write("\n");

    if (!acpi_map_physical_range(physical_address, 20)) {
        serial_write("[ACPI] Could not map RSDP header.\n");
        return 0;
    }

    struct acpi_rsdp *rsdp =
        (struct acpi_rsdp *)acpi_physical_to_virtual(physical_address);

    if (!rsdp)
        return 0;

    if (!acpi_signature_matches(rsdp, "RSD PTR ", 8)) {
        serial_write("[ACPI] Invalid RSDP signature.\n");
        return 0;
    }

    if (!acpi_checksum(rsdp, 20)) {
        serial_write("[ACPI] RSDP checksum failed.\n");
        return 0;
    }

    if (rsdp->revision >= 2) {
        if (!acpi_map_physical_range(physical_address, 36)) {
            serial_write("[ACPI] Could not map extended RSDP header.\n");
            return 0;
        }

        uint32_t length = rsdp->length;

        if (length < 36 || length > 4096) {
            serial_write("[ACPI] Invalid extended RSDP length.\n");
            return 0;
        }

        if (!acpi_map_physical_range(physical_address, length)) {
            serial_write("[ACPI] Could not map complete RSDP.\n");
            return 0;
        }

        if (!acpi_checksum(rsdp, length)) {
            serial_write("[ACPI] Extended RSDP checksum failed.\n");
            return 0;
        }
    }

    serial_write("[ACPI] RSDP validated successfully.\n");
    return rsdp;
}

/* =========================================
   ACPI TABLE LOOKUP
   ========================================= */

static struct acpi_sdt_header *acpi_find_table(
    struct acpi_rsdp *rsdp,
    const char *signature
)
{
    if (!rsdp)
        return 0;

    uint64_t root_address = 0;
    uint32_t entry_size = 4;
    int use_xsdt = 0;

    if (rsdp->revision >= 2 && rsdp->xsdt_address != 0) {
        root_address = rsdp->xsdt_address;
        entry_size = 8;
        use_xsdt = 1;
    } else {
        root_address = rsdp->rsdt_address;
    }

    if (root_address == 0)
        return 0;

    if (!acpi_map_physical_range(
            root_address, sizeof(struct acpi_sdt_header)))
        return 0;

    struct acpi_sdt_header *root =
        (struct acpi_sdt_header *)acpi_physical_to_virtual(root_address);

    if (!root)
        return 0;

    uint32_t root_length = root->length;

    if (root_length < sizeof(struct acpi_sdt_header) ||
        root_length > 1024 * 1024)
        return 0;

    if (!acpi_map_physical_range(root_address, root_length))
        return 0;

    if (use_xsdt) {
        if (!acpi_signature_matches(root, "XSDT", 4))
            return 0;
    } else {
        if (!acpi_signature_matches(root, "RSDT", 4))
            return 0;
    }

    if (!acpi_checksum(root, root_length))
        return 0;

    uint32_t entries_length =
        root_length - sizeof(struct acpi_sdt_header);

    if (entries_length % entry_size != 0)
        return 0;

    uint32_t count = entries_length / entry_size;

    for (uint32_t i = 0; i < count; i++) {
        uint64_t address;

        if (use_xsdt)
            address = acpi_read64(root, 36 + (uint64_t)i * 8);
        else
            address = acpi_read32(root, 36 + (uint64_t)i * 4);

        if (address == 0)
            continue;

        if (!acpi_map_physical_range(
                address, sizeof(struct acpi_sdt_header)))
            continue;

        struct acpi_sdt_header *table =
            (struct acpi_sdt_header *)acpi_physical_to_virtual(address);

        if (!table)
            continue;

        uint32_t table_length = table->length;

        if (table_length < sizeof(struct acpi_sdt_header) ||
            table_length > 1024 * 1024)
            continue;

        if (!acpi_map_physical_range(address, table_length))
            continue;

        if (!acpi_checksum(table, table_length))
            continue;

        if (acpi_signature_matches(table, signature, 4))
            return table;
    }

    return 0;
}

/* =========================================
   ACPI AML PARSING
   ========================================= */

static int acpi_aml_integer(
    const uint8_t *aml,
    uint32_t length,
    uint32_t *position,
    uint64_t *value
)
{
    if (*position >= length)
        return 0;

    uint8_t opcode = aml[*position];
    (*position)++;

    if (opcode == 0x00) {
        *value = 0;
        return 1;
    }

    if (opcode == 0x01) {
        *value = 1;
        return 1;
    }

    uint32_t bytes = 0;

    switch (opcode) {
        case 0x0A: bytes = 1; break;
        case 0x0B: bytes = 2; break;
        case 0x0C: bytes = 4; break;
        case 0x0E: bytes = 8; break;
        default: return 0;
    }

    if (*position > length || bytes > length - *position)
        return 0;

    uint64_t result = 0;

    for (uint32_t i = 0; i < bytes; i++)
        result |= (uint64_t)aml[*position + i] << (i * 8);

    *position += bytes;
    *value = result;

    return 1;
}

static int acpi_aml_package_length(
    const uint8_t *aml,
    uint32_t length,
    uint32_t *position,
    uint32_t *package_length
)
{
    if (*position >= length)
        return 0;

    uint8_t lead = aml[*position];
    (*position)++;

    uint32_t follow = lead >> 6;
    uint32_t result;

    if (follow == 0) {
        result = lead & 0x3F;
    } else {
        result = lead & 0x0F;

        for (uint32_t i = 0; i < follow; i++) {
            if (*position >= length)
                return 0;

            result |= (uint32_t)aml[*position] << (4 + i * 8);
            (*position)++;
        }
    }

    *package_length = result;
    return 1;
}

static int acpi_find_s5(
    const uint8_t *aml,
    uint32_t length,
    uint8_t *sleep_a,
    uint8_t *sleep_b
)
{
    for (uint32_t i = 0; i + 6 < length; i++) {
        if (aml[i] != 0x08)
            continue;

        if (aml[i + 1] != '_' ||
            aml[i + 2] != 'S' ||
            aml[i + 3] != '5' ||
            aml[i + 4] != '_')
            continue;

        uint32_t position = i + 5;
        uint32_t package_length = 0;

        if (position >= length || aml[position] != 0x12)
            continue;

        position++;

        uint32_t package_length_start = position;

        if (!acpi_aml_package_length(
                aml, length, &position, &package_length))
            continue;

        if (package_length < position - package_length_start)
            continue;

        uint64_t package_end =
            (uint64_t)package_length_start + package_length;

        if (package_end > length || package_end <= position)
            continue;

        uint8_t elements = aml[position++];

        if (elements < 2)
            continue;

        uint64_t type_a = 0;
        uint64_t type_b = 0;

        if (!acpi_aml_integer(
                aml, (uint32_t)package_end, &position, &type_a))
            continue;

        if (!acpi_aml_integer(
                aml, (uint32_t)package_end, &position, &type_b))
            continue;

        if (type_a > 7 || type_b > 7)
            continue;

        *sleep_a = (uint8_t)type_a;
        *sleep_b = (uint8_t)type_b;

        return 1;
    }

    return 0;
}

/* =========================================
   ACPI REGISTER ACCESS
   ========================================= */

static int acpi_register_read(
    const struct acpi_register *reg,
    uint16_t *value
)
{
    if (!reg || !value || reg->address == 0 || reg->bit_width < 16)
        return 0;

    if (reg->address_space == ACPI_SPACE_IO) {
        if (reg->address > 0xFFFF)
            return 0;

        *value = inw((uint16_t)reg->address);
        return 1;
    }

    if (reg->address_space == ACPI_SPACE_MEMORY) {
        if (!acpi_map_physical_range(reg->address, sizeof(uint16_t)))
            return 0;

        void *pointer = acpi_physical_to_virtual(reg->address);

        if (!pointer)
            return 0;

        *value = *(volatile uint16_t *)pointer;
        return 1;
    }

    return 0;
}

static int acpi_register_write(
    const struct acpi_register *reg,
    uint16_t value
)
{
    if (!reg || reg->address == 0 || reg->bit_width < 16)
        return 0;

    if (reg->address_space == ACPI_SPACE_IO) {
        if (reg->address > 0xFFFF)
            return 0;

        outw((uint16_t)reg->address, value);
        return 1;
    }

    if (reg->address_space == ACPI_SPACE_MEMORY) {
        if (!acpi_map_physical_range(reg->address, sizeof(uint16_t)))
            return 0;

        void *pointer = acpi_physical_to_virtual(reg->address);

        if (!pointer)
            return 0;

        *(volatile uint16_t *)pointer = value;
        return 1;
    }

    return 0;
}

static int acpi_get_gas(
    const struct acpi_sdt_header *fadt,
    uint32_t offset,
    struct acpi_register *reg
)
{
    if (!fadt || !reg)
        return 0;

    if (offset > fadt->length ||
        sizeof(struct acpi_gas) > fadt->length - offset)
        return 0;

    const uint8_t *bytes = (const uint8_t *)fadt;

    reg->address_space = bytes[offset];
    reg->bit_width = bytes[offset + 1];

    uint64_t address = 0;

    for (uint32_t i = 0; i < 8; i++)
        address |= (uint64_t)bytes[offset + 4 + i] << (i * 8);

    reg->address = address;

    if (bytes[offset + 2] != 0 || reg->bit_width < 16)
        return 0;

    return 1;
}

static int acpi_get_pm1_registers(
    const struct acpi_sdt_header *fadt,
    struct acpi_register *pm1a,
    struct acpi_register *pm1b
)
{
    if (!fadt || !pm1a || !pm1b)
        return 0;

    if (fadt->length < 90) {
        serial_write("[ACPI] FADT is too short for PM1 control fields.\n");
        return 0;
    }

    const uint8_t *bytes = (const uint8_t *)fadt;
    uint32_t pm1_control_length = bytes[89];

    if (pm1_control_length < 2)
        return 0;

    int have_pm1a = 0;
    int have_pm1b = 0;

    if (fadt->length >= 184)
        have_pm1a = acpi_get_gas(fadt, 172, pm1a);

    if (fadt->length >= 196)
        have_pm1b = acpi_get_gas(fadt, 184, pm1b);

    if (!have_pm1a) {
        uint32_t address = acpi_read32(fadt, 64);

        if (address != 0) {
            pm1a->address_space = ACPI_SPACE_IO;
            pm1a->address = address;
            pm1a->bit_width = (uint8_t)(pm1_control_length * 8);
            have_pm1a = 1;
        }
    }

    if (!have_pm1b) {
        uint32_t address = acpi_read32(fadt, 68);

        if (address != 0) {
            pm1b->address_space = ACPI_SPACE_IO;
            pm1b->address = address;
            pm1b->bit_width = (uint8_t)(pm1_control_length * 8);
            have_pm1b = 1;
        }
    }

    return have_pm1a;
}

static int acpi_enable_mode(
    const struct acpi_sdt_header *fadt,
    const struct acpi_register *pm1a
)
{
    uint16_t control = 0;

    if (!acpi_register_read(pm1a, &control))
        return 0;

    if (control & ACPI_SCI_EN)
        return 1;

    if (fadt->length < 53)
        return 0;

    uint32_t smi_command_port = acpi_read32(fadt, 48);
    uint8_t acpi_enable_command = acpi_read8(fadt, 52);

    if (smi_command_port == 0 ||
        acpi_enable_command == 0 ||
        smi_command_port > 0xFFFF)
        return 0;

    outb((uint16_t)smi_command_port, acpi_enable_command);

    for (uint32_t i = 0; i < 3000000; i++) {
        if (acpi_register_read(pm1a, &control) &&
            (control & ACPI_SCI_EN))
            return 1;

        __asm__ volatile ("pause");
    }

    return 0;
}

/* =========================================
   ACPI SHUTDOWN
   ========================================= */

static int acpi_shutdown(void)
{
    serial_write("\n[ACPI] Searching for ACPI firmware tables...\n");

    struct acpi_rsdp *rsdp = acpi_find_rsdp();

    if (!rsdp) {
        serial_write("[ACPI] RSDP not found.\n");
        return 0;
    }

    serial_write("[ACPI] RSDP found.\n");

    struct acpi_sdt_header *fadt = acpi_find_table(rsdp, "FACP");

    if (!fadt) {
        serial_write("[ACPI] FADT not found or invalid.\n");
        return 0;
    }

    serial_write("[ACPI] FADT found.\n");

    if (fadt->length < 44) {
        serial_write("[ACPI] FADT is too short to contain a DSDT address.\n");
        return 0;
    }

    uint64_t dsdt_address = acpi_read32(fadt, 40);

    if (fadt->length >= 148) {
        uint64_t extended_dsdt = acpi_read64(fadt, 140);

        if (extended_dsdt != 0)
            dsdt_address = extended_dsdt;
    }

    if (dsdt_address == 0) {
        serial_write("[ACPI] DSDT address unavailable.\n");
        return 0;
    }

    if (!acpi_map_physical_range(
            dsdt_address, sizeof(struct acpi_sdt_header))) {
        serial_write("[ACPI] Could not map DSDT header.\n");
        return 0;
    }

    struct acpi_sdt_header *dsdt =
        (struct acpi_sdt_header *)acpi_physical_to_virtual(dsdt_address);

    if (!dsdt) {
        serial_write("[ACPI] DSDT could not be mapped.\n");
        return 0;
    }

    uint32_t dsdt_length = dsdt->length;

    if (dsdt_length < sizeof(struct acpi_sdt_header) ||
        dsdt_length > 1024 * 1024) {
        serial_write("[ACPI] Invalid DSDT length.\n");
        return 0;
    }

    if (!acpi_map_physical_range(dsdt_address, dsdt_length)) {
        serial_write("[ACPI] Could not map complete DSDT.\n");
        return 0;
    }

    if (!acpi_signature_matches(dsdt, "DSDT", 4) ||
        !acpi_checksum(dsdt, dsdt_length)) {
        serial_write("[ACPI] DSDT is invalid.\n");
        return 0;
    }

    serial_write("[ACPI] DSDT found and checksum verified.\n");

    uint8_t sleep_type_a = 0;
    uint8_t sleep_type_b = 0;

    const uint8_t *aml =
        (const uint8_t *)dsdt + sizeof(struct acpi_sdt_header);

    uint32_t aml_length =
        dsdt_length - sizeof(struct acpi_sdt_header);

    if (!acpi_find_s5(
            aml, aml_length, &sleep_type_a, &sleep_type_b)) {
        serial_write("[ACPI] Could not find a supported _S5_ package.\n");
        return 0;
    }

    serial_write("[ACPI] S5 sleep types found.\n");

    serial_write("[ACPI] Sleep type A: ");
    serial_write_number(sleep_type_a);
    serial_write("\n");

    serial_write("[ACPI] Sleep type B: ");
    serial_write_number(sleep_type_b);
    serial_write("\n");

    struct acpi_register pm1a = {0};
    struct acpi_register pm1b = {0};

    if (!acpi_get_pm1_registers(fadt, &pm1a, &pm1b)) {
        serial_write("[ACPI] PM1a control register unavailable.\n");
        return 0;
    }

    serial_write("[ACPI] PM1 control registers found.\n");

    if (!acpi_enable_mode(fadt, &pm1a)) {
        serial_write("[ACPI] Could not enable ACPI mode.\n");
        return 0;
    }

    serial_write("[ACPI] ACPI mode enabled.\n");

    uint16_t pm1a_value = 0;
    uint16_t pm1b_value = 0;

    if (!acpi_register_read(&pm1a, &pm1a_value)) {
        serial_write("[ACPI] Could not read PM1a control register.\n");
        return 0;
    }

    int have_pm1b = pm1b.address != 0;

    if (have_pm1b &&
        !acpi_register_read(&pm1b, &pm1b_value)) {
        serial_write("[ACPI] Could not read PM1b control register.\n");
        return 0;
    }

    pm1a_value &= (uint16_t)~(ACPI_SLP_TYP_MASK | ACPI_SLP_EN);
    pm1a_value |= (uint16_t)(sleep_type_a << ACPI_SLP_TYP_SHIFT);
    pm1a_value |= ACPI_SLP_EN;

    pm1b_value &= (uint16_t)~(ACPI_SLP_TYP_MASK | ACPI_SLP_EN);
    pm1b_value |= (uint16_t)(sleep_type_b << ACPI_SLP_TYP_SHIFT);
    pm1b_value |= ACPI_SLP_EN;

    serial_write("[ACPI] Requesting S5 soft-off...\n");

    if (have_pm1b &&
        !acpi_register_write(&pm1b, pm1b_value)) {
        serial_write("[ACPI] PM1b write failed.\n");
        return 0;
    }

    if (!acpi_register_write(&pm1a, pm1a_value)) {
        serial_write("[ACPI] PM1a write failed.\n");
        return 0;
    }

    serial_write("[ACPI] Shutdown request sent. CPU halted.\n");

    kernel_halt();
    return 1;
}

/* =========================================
   REBOOT
   ========================================= */

static void shell_reboot(void)
{
    serial_write("\n[AngelOS] Restarting system...\n");

    __asm__ volatile ("cli" ::: "memory");

    serial_write("[REBOOT] Trying keyboard-controller reset...\n");

    int controller_ready = 0;

    for (uint32_t i = 0; i < 1000000; i++) {
        if ((inb(0x64) & 0x02) == 0) {
            controller_ready = 1;
            break;
        }
    }

    if (controller_ready) {
        outb(0x64, 0xFE);

        for (volatile uint32_t i = 0; i < 1000000; i++)
            __asm__ volatile ("pause");
    }

    serial_write("[REBOOT] Trying chipset reset...\n");

    outb(0xCF9, 0x02);

    for (volatile uint32_t i = 0; i < 100000; i++)
        __asm__ volatile ("pause");

    outb(0xCF9, 0x06);

    for (volatile uint32_t i = 0; i < 1000000; i++)
        __asm__ volatile ("pause");

    serial_write("[REBOOT] Trying triple-fault reset...\n");

    struct {
        uint16_t limit;
        uint64_t base;
    } __attribute__((packed)) null_idt = {
        .limit = 0,
        .base = 0
    };

    __asm__ volatile (
        "lidt %0\n"
        "int3"
        :
        : "m"(null_idt)
        : "memory"
    );

    serial_write("[REBOOT] Reset failed. CPU halted.\n");
    kernel_halt();
}

/* =========================================
   COMMAND DISPATCH
   ========================================= */


static void shell_editor(const char *filename)
{
    char buffer[FS_CONTENT_MAX];
    uint32_t length = 0;

    const char *existing = fs_read(filename);

    if (existing == 0) {
        if (!fs_create_file(filename)) {
            serial_write("\n[EDITOR] Could not create file.\n\n");
            return;
        }

        existing = fs_read(filename);
    }

    if (existing != 0) {
        while (existing[length] &&
               length < FS_CONTENT_MAX - 1) {
            buffer[length] = existing[length];
            length++;
        }
    }

    buffer[length] = '\0';

    serial_write("\n================================\n");
    serial_write("          AngelOS Editor\n");
    serial_write("================================\n");
    serial_write("File: ");
    serial_write(filename);
    serial_write("\n");
    serial_write("Ctrl+S = Save | Ctrl+Q = Quit\n");
    serial_write("--------------------------------\n");

    if (length > 0)
        serial_write(buffer);

    int modified = 0;

    for (;;) {
        __asm__ volatile ("cli" ::: "memory");

        int key = keyboard_getkey();

        if (key < 0) {
            __asm__ volatile ("sti; hlt" ::: "memory");
            continue;
        }

        __asm__ volatile ("sti" ::: "memory");

        /* Ctrl+S: Save */
        if (key == 19) {
            buffer[length] = '\0';

            if (fs_write(filename, buffer)) {
                serial_write("\n\n[EDITOR] File saved.\n");
                modified = 0;
            } else {
                serial_write("\n\n[EDITOR] Save failed!\n");
            }

            continue;
        }

        /* Ctrl+Q: Quit */
        if (key == 17) {
            if (modified)
                serial_write("\n\n[EDITOR] Unsaved changes discarded.\n");

            serial_write("[EDITOR] Closing editor.\n\n");
            return;
        }

        /* Enter: New line */
        if (key == '\n') {
            if (length < FS_CONTENT_MAX - 1) {
                buffer[length++] = '\n';
                buffer[length] = '\0';

                serial_write("\r\n");
                modified = 1;
            }

            continue;
        }

        /* Backspace */
        if (key == '\b' || key == 0x7F) {
            if (length > 0) {
                length--;
                buffer[length] = '\0';

                serial_write("\b \b");
                modified = 1;
            }

            continue;
        }

        /* Printable characters */
        if (key >= 32 && key <= 126) {
            if (length < FS_CONTENT_MAX - 1) {
                buffer[length++] = (char)key;
                buffer[length] = '\0';

                char output[2];
                output[0] = (char)key;
                output[1] = '\0';

                serial_write(output);
                modified = 1;
            }

            continue;
        }
    }
}

static void shell_dispatch(int argc, char *argv[])
{
    if (argc == 0)
        return;

    if (shell_equals(argv[0], "help")) {
        shell_help();
    }
    else if (shell_equals(argv[0], "clear")) {
        shell_clear();
    }
    else if (shell_equals(argv[0], "info")) {
        shell_info();
    }
    else if (shell_equals(argv[0], "version")) {
        shell_version();
    }
    else if (shell_equals(argv[0], "uptime")) {
        shell_uptime();
    }
    else if (shell_equals(argv[0], "date")) {
        shell_date();
    }
    else if (shell_equals(argv[0], "time")) {
        shell_time();
    }
    else if (shell_equals(argv[0], "memory")) {
        shell_memory();
    }
    else if (shell_equals(argv[0], "echo")) {
        serial_write("\n");

        for (int i = 1; i < argc; i++) {
            if (i > 1)
                serial_write(" ");

            serial_write(argv[i]);
        }

        serial_write("\n\n");
    }
    else if (shell_equals(argv[0], "alias")) {
        if (argc == 1) {
            shell_list_aliases();
        } else {
            char *equal = argv[1];

            while (*equal && *equal != '=')
                equal++;

            if (*equal == '=') {
                *equal++ = '\0';
                shell_create_alias(argv[1], equal);
            } else {
                serial_write("\nUsage: alias name=command\n\n");
            }
        }
    }
    else if (shell_equals(argv[0], "unalias")) {
        if (argc < 2)
            serial_write("\nUsage: unalias name\n\n");
        else
            shell_remove_alias(argv[1]);
    }
    else if (shell_equals(argv[0], "reboot")) {
        shell_reboot();
    }
    else if (shell_equals(argv[0], "shutdown")) {
        __asm__ volatile ("cli" ::: "memory");

        if (!acpi_shutdown()) {
            serial_write("\n[AngelOS] ACPI shutdown failed.\n");
            serial_write("[AngelOS] The system has been halted safely.\n");
            kernel_halt();
        }
    }

    else if (shell_equals(argv[0], "disk")) {
        shell_disk_list();
    }
    else if (shell_equals(argv[0], "diskread")) {
        uint32_t device_index = 0;
        uint32_t lba = 0;

        if (argc < 3 ||
            !shell_parse_u32(argv[1], &device_index) ||
            !shell_parse_u32(argv[2], &lba) ||
            device_index > 255) {
            serial_write("\nUsage: diskread <device-index> <LBA>\n");
            serial_write("Example: diskread 0 0\n\n");
        } else {
            shell_disk_read(device_index, lba);
        }
    }

    /* Filesystem commands */

    else if (shell_equals(argv[0], "crdir")) {
        if (argc < 2)
            serial_write("\nUsage: crdir <name>\n\n");
        else
            shell_fs_create_dir(argv[1]);
    }
    else if (shell_equals(argv[0], "list")) {
        serial_write("\n");
        fs_list(shell_fs_list_output);
        serial_write("\n");
    }
    else if (shell_equals(argv[0], "sdir")) {
        if (argc < 2)
            serial_write("\nUsage: sdir <path>\n\n");
        else
            shell_fs_change_dir(argv[1]);
    }
    else if (shell_equals(argv[0], "edit")) {
    if (argc < 2)
        serial_write("\nUsage: edit <filename>\n\n");
    else
        shell_editor(argv[1]);
}
    else if (shell_equals(argv[0], "crf")) {
        if (argc < 2)
            serial_write("\nUsage: crf <name>\n\n");
        else
            shell_fs_create_file(argv[1]);
    }
    else if (shell_equals(argv[0], "src")) {
        if (argc < 2)
            serial_write("\nUsage: src <filename>\n\n");
        else
            shell_fs_read(argv[1]);
    }
    else if (shell_equals(argv[0], "write")) {
        if (argc < 3) {
            serial_write("\nUsage: write <filename> <text>\n\n");
        } else {
            char contents[SHELL_INPUT_SIZE];
            uint32_t position = 0;

            contents[0] = '\0';

            for (int i = 2; i < argc; i++) {
                if (i > 2 && position < SHELL_INPUT_SIZE - 1)
                    contents[position++] = ' ';

                for (uint32_t j = 0;
                     argv[i][j] && position < SHELL_INPUT_SIZE - 1;
                     j++) {
                    contents[position++] = argv[i][j];
                }
            }

            contents[position] = '\0';
            shell_fs_write(argv[1], contents);
        }
    }
    else if (shell_equals(argv[0], "rm")) {
        if (argc < 2)
            serial_write("\nUsage: rm <name>\n\n");
        else
            shell_fs_remove(argv[1]);
    }
    else if (shell_equals(argv[0], "pwd")) {
        serial_write("\n");
        fs_pwd(shell_fs_pwd_output);
        serial_write("\n\n");
    }
    else {
        serial_write("\nUnknown command: ");
        serial_write(argv[0]);
        serial_write("\nType 'help' to see available commands.\n\n");
    }
}

static void shell_execute(char *command)
{
    char *argv[SHELL_MAX_ARGUMENTS];

    int argc = shell_parse_arguments(
        command, argv, SHELL_MAX_ARGUMENTS
    );

    if (argc == 0)
        return;

    int alias_index = shell_find_alias(argv[0]);

    if (alias_index >= 0) {
        char expansion[SHELL_INPUT_SIZE];

        shell_string_copy(expansion, aliases[alias_index].command);

        char *expanded[SHELL_MAX_ARGUMENTS];

        int expanded_count = shell_parse_arguments(
            expansion, expanded, SHELL_MAX_ARGUMENTS
        );

        for (int i = 1;
             i < argc && expanded_count < SHELL_MAX_ARGUMENTS;
             i++) {
            expanded[expanded_count++] = argv[i];
        }

        shell_dispatch(expanded_count, expanded);
        return;
    }

    shell_dispatch(argc, argv);
}

/* =========================================
   SHELL INPUT LOOP
   ========================================= */

static void shell_start(void)
{
    char input_line[SHELL_INPUT_SIZE];

    uint64_t input_length = 0;
    uint64_t cursor = 0;

    history_position = history_count;
    input_line[0] = '\0';
    history_draft[0] = '\0';

    shell_clear();

    serial_write("====================================\n");
    serial_write("          AngelOS Shell 1.6         \n");
    serial_write("====================================\n");
    serial_write("Welcome to AngelOS!\n");
    serial_write("Type 'help' to see available commands.\n\n");

    shell_print_prompt();

    for (;;) {
        __asm__ volatile ("cli" ::: "memory");

        int key = keyboard_getkey();

        if (key < 0) {
            __asm__ volatile ("sti; hlt" ::: "memory");
            continue;
        }

        __asm__ volatile ("sti" ::: "memory");

        if (key == '\n') {
            serial_write("\r\n");

            input_line[input_length] = '\0';

            shell_history_save(input_line);

            history_position = history_count;
            history_draft[0] = '\0';

            shell_execute(input_line);

            input_length = 0;
            cursor = 0;
            input_line[0] = '\0';

            shell_print_prompt();
            continue;
        }

        if (key == '\b' || key == 0x7F) {
            shell_backspace(input_line, &input_length, &cursor);
            history_position = history_count;
            continue;
        }

        if (key == '\t') {
            shell_tab_complete(input_line, &input_length, &cursor);
            history_position = history_count;
            continue;
        }

        if (key == KEYBOARD_KEY_UP) {
            shell_history_up(input_line);

            input_length = shell_string_length(input_line);
            cursor = input_length;

            shell_redraw_line(input_line, input_length, cursor);
            continue;
        }

        if (key == KEYBOARD_KEY_DOWN) {
            shell_history_down(input_line);

            input_length = shell_string_length(input_line);
            cursor = input_length;

            shell_redraw_line(input_line, input_length, cursor);
            continue;
        }

        if (key == KEYBOARD_KEY_LEFT) {
            if (cursor > 0) {
                cursor--;
                shell_print_cursor_left(1);
            }

            continue;
        }

        if (key == KEYBOARD_KEY_RIGHT) {
            if (cursor < input_length) {
                cursor++;
                serial_write("\033[1C");
            }

            continue;
        }

        if (key == KEYBOARD_KEY_HOME) {
            cursor = 0;
            shell_redraw_line(input_line, input_length, cursor);
            continue;
        }

        if (key == KEYBOARD_KEY_END) {
            cursor = input_length;
            shell_redraw_line(input_line, input_length, cursor);
            continue;
        }

        if (key == KEYBOARD_KEY_DELETE) {
            shell_delete(input_line, &input_length, cursor);
            history_position = history_count;
            continue;
        }

        if (key < 32 || key > 126)
            continue;

        shell_insert_character(
            input_line, &input_length, &cursor, (char)key
        );

        history_position = history_count;
    }
}

/* =========================================
   HALOROOT KERNEL
   ========================================= */

void kernel_main(void)
{
    serial_init();

    serial_write("\n");
    serial_write("====================================\n");
    serial_write("             AngelOS                \n");
    serial_write("====================================\n");

    serial_write("[HaloRoot] Kernel entry reached.\n");

    if (limine_base_revision[2] != 0) {
        serial_write("[ERROR] Limine revision unsupported.\n");
        kernel_halt();
    }

    serial_write("[OK] Boot protocol initialized.\n");
    serial_write("[OK] Architecture: x86-64.\n");
    serial_write("[OK] Kernel: HaloRoot 1.6.\n");
    serial_write("[OK] Serial output initialized.\n");

    serial_write("\n[INTERRUPTS] Initializing IDT...\n");

    if (!interrupts_init()) {
        serial_write("[ERROR] IDT initialization failed.\n");
        kernel_halt();
    }

    serial_write("[INTERRUPTS] IDT installed successfully.\n");
    serial_write("[INTERRUPTS] 32 CPU exception handlers installed.\n");
    serial_write("[INTERRUPTS] 16 hardware IRQ handlers available.\n");

    serial_write("\nWelcome to AngelOS.\n");
    serial_write("HaloRoot is alive!\n\n");

    if (memmap_request.response == 0 ||
        kernel_address_request.response == 0 ||
        hhdm_request.response == 0) {
        serial_write("[ERROR] Required Limine response unavailable.\n");
        kernel_halt();
    }

    serial_write("[MEMORY] Memory map received.\n");

    uint64_t virtual_start = (uint64_t)(uintptr_t)__kernel_start;
    uint64_t virtual_end = (uint64_t)(uintptr_t)__kernel_end;

    uint64_t physical_base =
        kernel_address_request.response->physical_base;

    uint64_t virtual_base =
        kernel_address_request.response->virtual_base;

    if (virtual_start < virtual_base ||
        virtual_end < virtual_start) {
        serial_write("[ERROR] Invalid kernel address range.\n");
        kernel_halt();
    }

    uint64_t start_offset = virtual_start - virtual_base;
    uint64_t end_offset = virtual_end - virtual_base;

    if (start_offset > UINT64_MAX - physical_base ||
        end_offset > UINT64_MAX - physical_base) {
        serial_write("[ERROR] Kernel address overflow.\n");
        kernel_halt();
    }

    uint64_t kernel_physical_start = physical_base + start_offset;
    uint64_t kernel_physical_end = physical_base + end_offset;

    serial_write("[MEMORY] Kernel physical start: ");
    serial_write_hex(kernel_physical_start);
    serial_write("\n");

    serial_write("[MEMORY] Kernel physical end:   ");
    serial_write_hex(kernel_physical_end);
    serial_write("\n");

    if (!pmm_init(
        memmap_request.response,
        kernel_physical_start,
        kernel_physical_end
    )) {
        serial_write("[ERROR] PMM initialization failed.\n");
        kernel_halt();
    }

    serial_write("[PMM] Physical memory manager initialized.\n");

    serial_write("\n========== MEMORY STATISTICS ==========\n");

    serial_write("[PMM] Total managed pages: ");
    serial_write_hex(pmm_get_total_pages());
    serial_write("\n");

    serial_write("[PMM] Used pages:          ");
    serial_write_hex(pmm_get_used_pages());
    serial_write("\n");

    serial_write("[PMM] Free pages:          ");
    serial_write_hex(pmm_get_free_pages());
    serial_write("\n");

    serial_write("[PMM] Allocation count:    ");
    serial_write_hex(pmm_get_allocation_count());
    serial_write("\n");

    serial_write("[PMM] Release count:       ");
    serial_write_hex(pmm_get_release_count());
    serial_write("\n");

    serial_write("=======================================\n");

    uint64_t page = pmm_alloc_page();

    if (page == 0) {
        serial_write("[ERROR] Page allocation failed.\n");
        kernel_halt();
    }

    serial_write("\n[PMM] Allocated physical page at: ");
    serial_write_hex(page);
    serial_write("\n");

    if (!pmm_free_page(page)) {
        serial_write("[ERROR] Page release failed.\n");
        kernel_halt();
    }

    serial_write("[PMM] Page successfully released.\n");

    uint64_t kernel_page =
        kernel_physical_start & ~(PMM_PAGE_SIZE - 1);

    if (!pmm_is_reserved_page(kernel_page)) {
        serial_write("[ERROR] Kernel page is not marked reserved!\n");
        kernel_halt();
    }

    serial_write("[PMM] Kernel page reservation verified.\n");

    if (pmm_is_managed_page(kernel_page)) {
        if (pmm_free_page(kernel_page)) {
            serial_write("[ERROR] Reserved kernel page was freed!\n");
            kernel_halt();
        }

        serial_write("[PMM] Kernel page cannot be released.\n");
    } else {
        serial_write("[PMM] Kernel page is outside managed memory.\n");
    }

    if (!vmm_init(hhdm_request.response)) {
        serial_write("[ERROR] VMM initialization failed.\n");
        kernel_halt();
    }

    serial_write("\n========== VIRTUAL MEMORY ==========\n");

    serial_write("[VMM] HHDM offset: ");
    serial_write_hex(vmm_get_hhdm_offset());
    serial_write("\n");

    serial_write("[VMM] Active PML4 physical address: ");
    serial_write_hex(vmm_get_current_pml4());
    serial_write("\n");

    serial_write("[VMM] Paging environment detected.\n");
    serial_write("====================================\n");

    serial_write("\n========== KERNEL HEAP =============\n");

    if (!heap_init()) {
        serial_write("[ERROR] Kernel heap initialization failed.\n");
        kernel_halt();
    }

    serial_write("[HEAP] Kernel heap initialized.\n");

    uint8_t *test_a = (uint8_t *)kmalloc(64);
    uint8_t *test_b = (uint8_t *)kmalloc(128);

    if (!test_a || !test_b) {
        serial_write("[ERROR] kmalloc test failed.\n");
        kernel_halt();
    }

    for (uint64_t i = 0; i < 64; i++)
        test_a[i] = 0xA5;

    for (uint64_t i = 0; i < 128; i++)
        test_b[i] = 0x5A;

    for (uint64_t i = 0; i < 64; i++) {
        if (test_a[i] != 0xA5) {
            serial_write("[ERROR] Heap memory test failed.\n");
            kernel_halt();
        }
    }

    for (uint64_t i = 0; i < 128; i++) {
        if (test_b[i] != 0x5A) {
            serial_write("[ERROR] Heap memory test failed.\n");
            kernel_halt();
        }
    }

    serial_write("[HEAP] Memory read/write test passed.\n");

    uint32_t *zero_test =
        (uint32_t *)kcalloc(16, sizeof(uint32_t));

    if (!zero_test) {
        serial_write("[ERROR] kcalloc allocation failed.\n");
        kernel_halt();
    }

    for (uint64_t i = 0; i < 16; i++) {
        if (zero_test[i] != 0) {
            serial_write("[ERROR] kcalloc zero test failed.\n");
            kernel_halt();
        }
    }

    serial_write("[HEAP] kcalloc test passed.\n");

    uint8_t *resized = (uint8_t *)krealloc(test_a, 128);

    if (!resized) {
        serial_write("[ERROR] krealloc failed.\n");
        kernel_halt();
    }

    for (uint64_t i = 0; i < 64; i++) {
        if (resized[i] != 0xA5) {
            serial_write("[ERROR] krealloc data preservation failed.\n");
            kernel_halt();
        }
    }

    serial_write("[HEAP] krealloc test passed.\n");

    kfree(resized);
    kfree(test_b);
    kfree(zero_test);

    serial_write("[HEAP] kfree test passed.\n");

    serial_write("\n[HEAP] Heap pages: ");
    serial_write_hex(heap_get_page_count());
    serial_write("\n");

    serial_write("[HEAP] Free blocks: ");
    serial_write_hex(heap_get_free_block_count());
    serial_write("\n");

    serial_write("====================================\n");
    serial_write("\n[OK] HaloRoot 1.5 memory tests complete.\n");

    /* Initialize the RAM filesystem after the heap. */

    serial_write("\n[FILESYSTEM] Initializing RAM filesystem...\n");

    if (!fs_init()) {
        serial_write("[ERROR] Filesystem initialization failed.\n");
        kernel_halt();
    }

    serial_write("[FILESYSTEM] RAM filesystem initialized.\n");

    serial_write("[FILESYSTEM] Root directory ready.\n");

    serial_write("\n[ATA] Probing legacy IDE channels...\n");

    uint32_t ata_devices = ata_init();

    if (ata_devices == 0)
        serial_write("[ATA] No supported ATA disks detected.\n");
    else {
        serial_write("[ATA] Detected disks: ");
        serial_write_number(ata_devices);
        serial_write("\n");
    }

    serial_write("\n[RTC] Initializing hardware clock...\n");

    if (rtc_init())
        serial_write("[RTC] Hardware clock initialized.\n");
    else
        serial_write("[RTC] Warning: Hardware clock unavailable.\n");

    serial_write("\n========== HARDWARE INTERRUPTS ==========\n");

    pic_init();

    serial_write("[PIC] Master PIC remapped to vector 32.\n");
    serial_write("[PIC] Slave PIC remapped to vector 40.\n");

    serial_write("\n[PIT] Initializing system timer...\n");

    if (!pit_init(100)) {
        serial_write("[ERROR] PIT initialization failed.\n");
        kernel_halt();
    }

    serial_write("[PIT] Timer configured at 100 Hz.\n");

    serial_write("\n[KEYBOARD] Initializing keyboard driver...\n");

    if (!keyboard_init()) {
        serial_write("[ERROR] Keyboard initialization failed.\n");
        kernel_halt();
    }

    serial_write("[KEYBOARD] IRQ1 handler registered.\n");

    pic_unmask_irq(0);
    pic_unmask_irq(1);

    serial_write("[PIC] Timer IRQ0 enabled.\n");
    serial_write("[PIC] Keyboard IRQ1 enabled.\n");

    serial_write("\n[OK] Hardware interrupt handlers installed.\n");

    __asm__ volatile ("sti");

    serial_write("[HALOROOT] Interrupts enabled.\n");
    serial_write("[HALOROOT] System timer running.\n");

    shell_start();
}