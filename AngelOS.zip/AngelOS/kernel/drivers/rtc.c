
#include "rtc.h"

#define RTC_INDEX 0x70
#define RTC_DATA  0x71

#define RTC_SECONDS  0x00
#define RTC_MINUTES  0x02
#define RTC_HOURS    0x04
#define RTC_DAY      0x07
#define RTC_MONTH    0x08
#define RTC_YEAR     0x09
#define RTC_CENTURY  0x32
#define RTC_STATUS_A 0x0A
#define RTC_STATUS_B 0x0B

#define RTC_UIP 0x80
#define RTC_BINARY 0x04
#define RTC_24_HOUR 0x02
#define RTC_PM 0x80

static inline void outb(uint16_t port, uint8_t value)
{
    __asm__ volatile ("outb %0, %1" :: "a"(value), "Nd"(port));
}

static inline uint8_t inb(uint16_t port)
{
    uint8_t value;
    __asm__ volatile ("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static uint8_t rtc_read(uint8_t reg)
{
    /* Keep NMI enabled while selecting the CMOS register. */
    outb(RTC_INDEX, reg);
    return inb(RTC_DATA);
}

static int rtc_wait(void)
{
    for (uint32_t i = 0; i < 1000000; i++) {
        if (!(rtc_read(RTC_STATUS_A) & RTC_UIP))
            return 1;
    }

    return 0;
}

static uint8_t from_bcd(uint8_t value)
{
    return (uint8_t)(((value >> 4) * 10) + (value & 0x0F));
}

int rtc_get_datetime(struct rtc_datetime *dt)
{
    if (!dt)
        return 0;

    uint8_t sec, min, hour, day, month, year, century;
    uint8_t status_b;
    int stable = 0;

    for (int attempt = 0; attempt < 8; attempt++) {
        uint8_t s1, m1, h1, d1, mo1, y1, c1;

        if (!rtc_wait())
            return 0;

        s1  = rtc_read(RTC_SECONDS);
        m1  = rtc_read(RTC_MINUTES);
        h1  = rtc_read(RTC_HOURS);
        d1  = rtc_read(RTC_DAY);
        mo1 = rtc_read(RTC_MONTH);
        y1  = rtc_read(RTC_YEAR);
        c1  = rtc_read(RTC_CENTURY);

        if (!rtc_wait())
            return 0;

        sec     = rtc_read(RTC_SECONDS);
        min     = rtc_read(RTC_MINUTES);
        hour    = rtc_read(RTC_HOURS);
        day     = rtc_read(RTC_DAY);
        month   = rtc_read(RTC_MONTH);
        year    = rtc_read(RTC_YEAR);
        century = rtc_read(RTC_CENTURY);

        if (s1 == sec && m1 == min && h1 == hour &&
            d1 == day && mo1 == month && y1 == year &&
            c1 == century) {
            stable = 1;
            break;
        }
    }

    if (!stable)
        return 0;

    status_b = rtc_read(RTC_STATUS_B);

    int binary = (status_b & RTC_BINARY) != 0;
    int mode24 = (status_b & RTC_24_HOUR) != 0;
    int pm = (hour & RTC_PM) != 0;

    hour &= 0x7F;

    if (!binary) {
        sec = from_bcd(sec);
        min = from_bcd(min);
        hour = from_bcd(hour);
        day = from_bcd(day);
        month = from_bcd(month);
        year = from_bcd(year);
        century = from_bcd(century);
    }

    if (!mode24) {
        hour %= 12;
        if (pm)
            hour += 12;
    }

    uint16_t full_year;

    if (century >= 19 && century <= 99) {
        full_year = (uint16_t)(century * 100U + year);
    } else {
        full_year = year >= 70
            ? (uint16_t)(1900U + year)
            : (uint16_t)(2000U + year);
    }

    if (month < 1 || month > 12 ||
        day < 1 || day > 31 ||
        hour > 23 || min > 59 || sec > 59)
        return 0;

    dt->year = full_year;
    dt->month = month;
    dt->day = day;
    dt->hour = hour;
    dt->minute = min;
    dt->second = sec;

    return 1;
}

int rtc_init(void)
{
    struct rtc_datetime test;

    return rtc_wait() && rtc_get_datetime(&test);
}
