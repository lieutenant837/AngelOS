
#ifndef HALOROOT_ATA_H
#define HALOROOT_ATA_H

#include <stdint.h>

struct ata_device_info {
    uint8_t channel;
    uint8_t drive;
    uint64_t sectors;
    char model[41];
};

uint32_t ata_init(void);
uint32_t ata_get_device_count(void);
const struct ata_device_info *ata_get_device(uint32_t index);

int ata_is_available(void);
uint32_t ata_get_sector_count(void);

int ata_read_sector(uint32_t lba, uint8_t *buffer);
int ata_write_sector(uint32_t lba, const uint8_t *buffer);

int ata_read_sector_device(
    uint8_t device_index,
    uint32_t lba,
    uint16_t *buffer
);

int ata_write_sector_device(
    uint8_t device_index,
    uint32_t lba,
    const uint16_t *buffer
);

#endif
