#ifndef HALOROOT_PIT_H
#define HALOROOT_PIT_H

#include <stdint.h>

int pit_init(uint32_t frequency);
uint64_t pit_get_ticks(void);

#endif