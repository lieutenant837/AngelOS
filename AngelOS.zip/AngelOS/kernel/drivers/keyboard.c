
#include <stdint.h>

#include "keyboard.h"
#include "../interrupts/interrupts.h"

#define KEYBOARD_DATA_PORT       0x60
#define KEYBOARD_STATUS_PORT     0x64
#define KEYBOARD_COMMAND_PORT    0x64
#define KEYBOARD_BUFFER_SIZE     256

static const char keymap[128] = {
    0, 27, '1', '2', '3', '4', '5', '6',
    '7', '8', '9', '0', '-', '=', '\b', '\t',
    'q', 'w', 'e', 'r', 't', 'y', 'u', 'i',
    'o', 'p', '[', ']', '\n', 0, 'a', 's',
    'd', 'f', 'g', 'h', 'j', 'k', 'l', ';',
    '\'', '`', 0, '\\', 'z', 'x', 'c', 'v',
    'b', 'n', 'm', ',', '.', '/', 0, '*',
    0, ' ', 0
};

static const char shift_keymap[128] = {
    0, 27, '!', '@', '#', '$', '%', '^',
    '&', '*', '(', ')', '_', '+', '\b', '\t',
    'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I',
    'O', 'P', '{', '}', '\n', 0, 'A', 'S',
    'D', 'F', 'G', 'H', 'J', 'K', 'L', ':',
    '"', '~', 0, '|', 'Z', 'X', 'C', 'V',
    'B', 'N', 'M', '<', '>', '?', 0, '*',
    0, ' ', 0
};

static volatile uint16_t input_buffer[KEYBOARD_BUFFER_SIZE];
static volatile uint8_t buffer_head;
static volatile uint8_t buffer_tail;

static volatile uint8_t left_shift;
static volatile uint8_t right_shift;
static volatile uint8_t control_down;
static volatile uint8_t alt_down;
static volatile uint8_t caps_lock;

static uint8_t extended_prefix;
static uint8_t pause_bytes;

static void keyboard_interrupt_handler(struct interrupt_frame *frame);

static inline uint8_t inb(uint16_t port)
{
    uint8_t value;
    __asm__ volatile ("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static inline void outb(uint16_t port, uint8_t value)
{
    __asm__ volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
}

static int wait_input_empty(void)
{
    for (uint32_t i = 0; i < 100000; i++) {
        if (!(inb(KEYBOARD_STATUS_PORT) & 0x02))
            return 1;
    }
    return 0;
}

static int wait_output_full(void)
{
    for (uint32_t i = 0; i < 100000; i++) {
        if (inb(KEYBOARD_STATUS_PORT) & 0x01)
            return 1;
    }
    return 0;
}

static void keyboard_controller_init(void)
{
    for (uint32_t i = 0; i < 32; i++) {
        if (!(inb(KEYBOARD_STATUS_PORT) & 0x01))
            break;
        (void)inb(KEYBOARD_DATA_PORT);
    }

    if (wait_input_empty())
        outb(KEYBOARD_COMMAND_PORT, 0xAE);

    if (wait_input_empty()) {
        outb(KEYBOARD_COMMAND_PORT, 0x20);

        if (wait_output_full()) {
            uint8_t config = inb(KEYBOARD_DATA_PORT);

            config |= 0x41;
            config &= (uint8_t)~0x10;

            if (wait_input_empty()) {
                outb(KEYBOARD_COMMAND_PORT, 0x60);
                if (wait_input_empty())
                    outb(KEYBOARD_DATA_PORT, config);
            }
        }
    }
}

static void keyboard_buffer_push(uint16_t key)
{
    uint8_t next = (uint8_t)(buffer_head + 1);

    if (next == buffer_tail)
        return;

    input_buffer[buffer_head] = key;
    __asm__ volatile ("" ::: "memory");
    buffer_head = next;
}

int keyboard_getkey(void)
{
    if (buffer_tail == buffer_head)
        return -1;

    uint16_t key = input_buffer[buffer_tail];
    buffer_tail = (uint8_t)(buffer_tail + 1);
    return key;
}

int keyboard_getchar(void)
{
    int key = keyboard_getkey();

    if (key < 0 || key > 255)
        return -1;

    return key;
}

static void keyboard_process_extended(uint8_t scancode)
{
    uint8_t released = scancode & 0x80;
    uint8_t key = scancode & 0x7F;

    if (key == 0x1D) {
        control_down = !released;
        return;
    }

    if (key == 0x38) {
        alt_down = !released;
        return;
    }

    if (released || alt_down)
        return;

    switch (key) {
        case 0x48: keyboard_buffer_push(KEYBOARD_KEY_UP); break;
        case 0x50: keyboard_buffer_push(KEYBOARD_KEY_DOWN); break;
        case 0x4B: keyboard_buffer_push(KEYBOARD_KEY_LEFT); break;
        case 0x4D: keyboard_buffer_push(KEYBOARD_KEY_RIGHT); break;
        case 0x47: keyboard_buffer_push(KEYBOARD_KEY_HOME); break;
        case 0x4F: keyboard_buffer_push(KEYBOARD_KEY_END); break;
        case 0x53: keyboard_buffer_push(KEYBOARD_KEY_DELETE); break;
        default: break;
    }
}

static void keyboard_process_scancode(uint8_t scancode)
{
    if (pause_bytes) {
        pause_bytes--;
        return;
    }

    if (scancode == 0xE1) {
        extended_prefix = 0;
        pause_bytes = 5;
        return;
    }

    if (scancode == 0xE0) {
        extended_prefix = 1;
        return;
    }

    if (extended_prefix) {
        extended_prefix = 0;
        keyboard_process_extended(scancode);
        return;
    }

    uint8_t released = scancode & 0x80;
    uint8_t key = scancode & 0x7F;

    if (key == 0x2A) { left_shift = !released; return; }
    if (key == 0x36) { right_shift = !released; return; }
    if (key == 0x1D) { control_down = !released; return; }
    if (key == 0x38) { alt_down = !released; return; }

    if (released)
        return;

    if (key == 0x3A) {
        caps_lock = !caps_lock;
        return;
    }

    if (key >= 128)
        return;

    uint8_t shift = left_shift || right_shift;
    char character = shift ? shift_keymap[key] : keymap[key];

    if (key >= 0x10 && key <= 0x32) {
        char normal = keymap[key];

        if (normal >= 'a' && normal <= 'z') {
            character = (shift != caps_lock)
                ? shift_keymap[key]
                : normal;
        }
    }

    if (control_down && character >= 'a' && character <= 'z')
        character = (char)(character - 'a' + 1);
    else if (control_down && character >= 'A' && character <= 'Z')
        character = (char)(character - 'A' + 1);

    if (!alt_down && character)
        keyboard_buffer_push((uint8_t)character);
}

static void keyboard_interrupt_handler(struct interrupt_frame *frame)
{
    (void)frame;

    keyboard_process_scancode(inb(KEYBOARD_DATA_PORT));
}

int keyboard_init(void)
{
    buffer_head = 0;
    buffer_tail = 0;

    left_shift = 0;
    right_shift = 0;
    control_down = 0;
    alt_down = 0;
    caps_lock = 0;
    extended_prefix = 0;
    pause_bytes = 0;

    if (!irq_register_handler(1, keyboard_interrupt_handler))
        return 0;

    keyboard_controller_init();

    return 1;
}
