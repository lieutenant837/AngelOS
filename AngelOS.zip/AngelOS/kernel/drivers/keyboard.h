
#ifndef HALOROOT_KEYBOARD_H
#define HALOROOT_KEYBOARD_H

#include <stdint.h>

/* Special keyboard events (values outside the ASCII range). */
#define KEYBOARD_KEY_UP       0x100
#define KEYBOARD_KEY_DOWN     0x101
#define KEYBOARD_KEY_LEFT     0x102
#define KEYBOARD_KEY_RIGHT    0x103
#define KEYBOARD_KEY_HOME     0x104
#define KEYBOARD_KEY_END      0x105
#define KEYBOARD_KEY_DELETE   0x106

int keyboard_init(void);

/*
 * Returns an ASCII character or a KEYBOARD_KEY_* event.
 * Returns -1 when the input buffer is empty.
 */
int keyboard_getkey(void);

/*
 * Compatibility function:
 * Returns the next ordinary character, or -1.
 * Special key events are discarded by this function.
 */
int keyboard_getchar(void);

#endif
