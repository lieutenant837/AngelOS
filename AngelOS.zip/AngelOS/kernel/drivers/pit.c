
#include <stdint.h>

#include "pit.h"
#include "../interrupts/interrupts.h"

#define PIT_CHANNEL_0 0x40
#define PIT_COMMAND 0x43
#define PIT_INPUT_FREQUENCY 1193182

static volatile uint64_t timer_ticks = 0;

static inline void outb(uint16_t port, uint8_t value)
{
    __asm__ volatile (
        "outb %0, %1"
        :
        : "a"(value), "Nd"(port)
    );
}

static void pit_interrupt_handler(struct interrupt_frame *frame)
{
    (void)frame;

    timer_ticks++;
}

int pit_init(uint32_t frequency)
{
    if (frequency == 0 ||
        frequency > PIT_INPUT_FREQUENCY) {
        return 0;
    }

    uint32_t divisor = PIT_INPUT_FREQUENCY / frequency;

    if (divisor == 0 || divisor > 65535) {
        return 0;
    }

    if (!irq_register_handler(0, pit_interrupt_handler)) {
        return 0;
    }

    outb(PIT_COMMAND, 0x36);

    outb(PIT_CHANNEL_0, (uint8_t)(divisor & 0xFF));
    outb(PIT_CHANNEL_0, (uint8_t)((divisor >> 8) & 0xFF));

    return 1;
}

uint64_t pit_get_ticks(void)
{
    return timer_ticks;
}
