
#include "ata.h"

#define ATA_PRIMARY_IO       0x1F0
#define ATA_PRIMARY_CTRL     0x3F6
#define ATA_SECONDARY_IO     0x170
#define ATA_SECONDARY_CTRL   0x376

#define ATA_REG_DATA         0
#define ATA_REG_ERROR        1
#define ATA_REG_FEATURES     1
#define ATA_REG_SECCOUNT0    2
#define ATA_REG_LBA0         3
#define ATA_REG_LBA1         4
#define ATA_REG_LBA2         5
#define ATA_REG_HDDEVSEL     6
#define ATA_REG_COMMAND      7
#define ATA_REG_STATUS       7

#define ATA_CMD_IDENTIFY       0xEC
#define ATA_CMD_READ_PIO       0x20
#define ATA_CMD_WRITE_PIO      0x30
#define ATA_CMD_CACHE_FLUSH    0xE7

#define ATA_SR_ERR  0x01
#define ATA_SR_DRQ  0x08
#define ATA_SR_DF   0x20
#define ATA_SR_BSY  0x80

#define ATA_TIMEOUT 1000000U
#define ATA_MAX_DEVICES 4

struct ata_channel {
    uint16_t io;
    uint16_t control;
};

static const struct ata_channel channels[2] = {
    { ATA_PRIMARY_IO, ATA_PRIMARY_CTRL },
    { ATA_SECONDARY_IO, ATA_SECONDARY_CTRL }
};

static struct ata_device_info devices[ATA_MAX_DEVICES];
static uint32_t device_count;

static inline void outb(uint16_t port, uint8_t value)
{
    __asm__ volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
}

static inline uint8_t inb(uint16_t port)
{
    uint8_t value;
    __asm__ volatile ("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static inline void outw(uint16_t port, uint16_t value)
{
    __asm__ volatile ("outw %0, %1" : : "a"(value), "Nd"(port));
}

static inline uint16_t inw(uint16_t port)
{
    uint16_t value;
    __asm__ volatile ("inw %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static void ata_delay_400ns(const struct ata_channel *channel)
{
    (void)inb(channel->control);
    (void)inb(channel->control);
    (void)inb(channel->control);
    (void)inb(channel->control);
}

static int ata_wait_not_busy(const struct ata_channel *channel)
{
    for (uint32_t i = 0; i < ATA_TIMEOUT; i++) {
        uint8_t status = inb(channel->io + ATA_REG_STATUS);

        if (status == 0x00 || status == 0xFF)
            return 0;

        if ((status & ATA_SR_BSY) == 0)
            return (status & (ATA_SR_ERR | ATA_SR_DF)) == 0;

        __asm__ volatile ("pause");
    }

    return 0;
}

static int ata_wait_drq(const struct ata_channel *channel)
{
    for (uint32_t i = 0; i < ATA_TIMEOUT; i++) {
        uint8_t status = inb(channel->io + ATA_REG_STATUS);

        if (status == 0x00 || status == 0xFF)
            return 0;

        if (status & (ATA_SR_ERR | ATA_SR_DF))
            return 0;

        if ((status & ATA_SR_BSY) == 0 && (status & ATA_SR_DRQ))
            return 1;

        __asm__ volatile ("pause");
    }

    return 0;
}


static int ata_wait_write_complete(const struct ata_channel *channel)
{
    for (uint32_t i = 0; i < ATA_TIMEOUT; i++) {
        uint8_t status = inb(channel->io + ATA_REG_STATUS);

        if (status == 0x00 || status == 0xFF)
            return 0;

        if (status & (ATA_SR_ERR | ATA_SR_DF))
            return 0;

        if ((status & ATA_SR_BSY) == 0 &&
            (status & ATA_SR_DRQ) == 0)
            return 1;

        __asm__ volatile ("pause");
    }

    return 0;
}


static void ata_copy_model(char destination[41], const uint16_t identify[256])
{
    for (uint32_t i = 0; i < 20; i++) {
        destination[i * 2] = (char)(identify[27 + i] >> 8);
        destination[i * 2 + 1] = (char)(identify[27 + i] & 0xFF);
    }

    destination[40] = '\0';

    for (int i = 39; i >= 0 && destination[i] == ' '; i--)
        destination[i] = '\0';

    for (uint32_t i = 0; destination[i]; i++) {
        if ((unsigned char)destination[i] < 32 ||
            (unsigned char)destination[i] > 126)
            destination[i] = '?';
    }
}

static int ata_identify(uint8_t channel_index, uint8_t drive_index,
                        struct ata_device_info *result)
{
    const struct ata_channel *channel = &channels[channel_index];
    uint16_t identify[256];

    /* Disable device IRQs; this driver polls the status register. */
    outb(channel->control, 0x02);
    outb(channel->io + ATA_REG_HDDEVSEL,
         (uint8_t)(0xA0 | (drive_index << 4)));
    ata_delay_400ns(channel);

    outb(channel->io + ATA_REG_SECCOUNT0, 0);
    outb(channel->io + ATA_REG_LBA0, 0);
    outb(channel->io + ATA_REG_LBA1, 0);
    outb(channel->io + ATA_REG_LBA2, 0);
    outb(channel->io + ATA_REG_COMMAND, ATA_CMD_IDENTIFY);

    uint8_t status = inb(channel->io + ATA_REG_STATUS);
    if (status == 0x00 || status == 0xFF)
        return 0;

    if (!ata_wait_not_busy(channel))
        return 0;

    /* Non-zero signature bytes identify ATAPI/other devices, not ATA disks. */
    if (inb(channel->io + ATA_REG_LBA1) != 0 ||
        inb(channel->io + ATA_REG_LBA2) != 0)
        return 0;

    if (!ata_wait_drq(channel))
        return 0;

    for (uint32_t i = 0; i < 256; i++)
        identify[i] = inw(channel->io + ATA_REG_DATA);

    uint64_t sectors = (uint32_t)identify[60] |
                       ((uint64_t)identify[61] << 16);

    if (sectors == 0)
        return 0;

    result->channel = channel_index;
    result->drive = drive_index;
    result->sectors = sectors;
    ata_copy_model(result->model, identify);
    return 1;
}

uint32_t ata_init(void)
{
    device_count = 0;

    for (uint8_t channel = 0; channel < 2; channel++) {
        for (uint8_t drive = 0; drive < 2; drive++) {
            if (device_count >= ATA_MAX_DEVICES)
                return device_count;

            struct ata_device_info candidate;

            if (ata_identify(channel, drive, &candidate))
                devices[device_count++] = candidate;
        }
    }

    return device_count;
}

uint32_t ata_get_device_count(void)
{
    return device_count;
}

const struct ata_device_info *ata_get_device(uint32_t index)
{
    if (index >= device_count)
        return 0;

    return &devices[index];
}

static int ata_select_lba28(uint8_t device_index, uint32_t lba,
                            const struct ata_channel **selected_channel)
{
    if (device_index >= device_count || lba >= 0x10000000U)
        return 0;

    const struct ata_device_info *device = &devices[device_index];
    const struct ata_channel *channel = &channels[device->channel];

    if ((uint64_t)lba >= device->sectors)
        return 0;

    outb(channel->io + ATA_REG_HDDEVSEL,
         (uint8_t)(0xE0 | (device->drive << 4) | ((lba >> 24) & 0x0F)));
    ata_delay_400ns(channel);

    if (!ata_wait_not_busy(channel))
        return 0;

    outb(channel->io + ATA_REG_FEATURES, 0);
    outb(channel->io + ATA_REG_SECCOUNT0, 1);
    outb(channel->io + ATA_REG_LBA0, (uint8_t)lba);
    outb(channel->io + ATA_REG_LBA1, (uint8_t)(lba >> 8));
    outb(channel->io + ATA_REG_LBA2, (uint8_t)(lba >> 16));

    *selected_channel = channel;
    return 1;
}


int ata_write_sector_device(uint8_t device_index, uint32_t lba,
                            const uint16_t *buffer)
{
    const struct ata_channel *channel;

    if (!buffer || !ata_select_lba28(device_index, lba, &channel))
        return 0;

    outb(channel->io + ATA_REG_COMMAND, ATA_CMD_WRITE_PIO);

    if (!ata_wait_drq(channel))
        return 0;

    for (uint32_t i = 0; i < 256; i++)
        outw(channel->io + ATA_REG_DATA, buffer[i]);

    ata_delay_400ns(channel);

    if (!ata_wait_write_complete(channel))
        return 0;

    outb(channel->io + ATA_REG_COMMAND, ATA_CMD_CACHE_FLUSH);
    ata_delay_400ns(channel);

    return ata_wait_not_busy(channel);
}


/* =========================================
   FILESYSTEM COMPATIBILITY API
   ========================================= */

int ata_is_available(void)
{
    return device_count > 0;
}

uint32_t ata_get_sector_count(void)
{
    if (device_count == 0)
        return 0;

    if (devices[0].sectors > 0xFFFFFFFFULL)
        return 0xFFFFFFFFU;

    return (uint32_t)devices[0].sectors;
}

int ata_read_sector_device(uint8_t device_index,
                           uint32_t lba,
                           uint16_t *buffer)
{
    const struct ata_channel *channel;

    if (!buffer || !ata_select_lba28(device_index, lba, &channel))
        return 0;

    outb(channel->io + ATA_REG_COMMAND, ATA_CMD_READ_PIO);

    if (!ata_wait_drq(channel))
        return 0;

    for (uint32_t i = 0; i < 256; i++)
        buffer[i] = inw(channel->io + ATA_REG_DATA);

    ata_delay_400ns(channel);

    return ata_wait_not_busy(channel);
}

int ata_read_sector(uint32_t lba, uint8_t *buffer)
{
    if (!buffer)
        return 0;

    uint16_t words[256];

    if (!ata_read_sector_device(0, lba, words))
        return 0;

    for (uint32_t i = 0; i < 256; i++) {
        buffer[i * 2]     = (uint8_t)(words[i] & 0xFF);
        buffer[i * 2 + 1] = (uint8_t)(words[i] >> 8);
    }

    return 1;
}

int ata_write_sector(uint32_t lba, const uint8_t *buffer)
{
    if (!buffer)
        return 0;

    uint16_t words[256];

    for (uint32_t i = 0; i < 256; i++) {
        words[i] = (uint16_t)buffer[i * 2] |
                   ((uint16_t)buffer[i * 2 + 1] << 8);
    }

    return ata_write_sector_device(0, lba, words);
}