
#ifndef HALOROOT_HEAP_H
#define HALOROOT_HEAP_H

#include <stddef.h>
#include <stdint.h>

int heap_init(void);

void *kmalloc(size_t size);
void kfree(void *pointer);

void *kcalloc(size_t count, size_t size);
void *krealloc(void *pointer, size_t size);

uint64_t heap_get_page_count(void);
uint64_t heap_get_free_block_count(void);

#endif
