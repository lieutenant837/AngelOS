
#ifndef HALOROOT_PMM_H
#define HALOROOT_PMM_H

#include <stdint.h>

#define PMM_PAGE_SIZE 4096ULL

struct limine_memmap_entry {
    uint64_t base;
    uint64_t length;
    uint64_t type;
};

struct limine_memmap_response {
    uint64_t revision;
    uint64_t entry_count;
    struct limine_memmap_entry **entries;
};

struct limine_memmap_request {
    uint64_t id[4];
    uint64_t revision;
    struct limine_memmap_response *response;
};

struct limine_kernel_address_response {
    uint64_t revision;
    uint64_t physical_base;
    uint64_t virtual_base;
};

struct limine_kernel_address_request {
    uint64_t id[4];
    uint64_t revision;
    struct limine_kernel_address_response *response;
};

int pmm_init(
    const struct limine_memmap_response *response,
    uint64_t kernel_physical_start,
    uint64_t kernel_physical_end
);

uint64_t pmm_alloc_page(void);
int pmm_free_page(uint64_t physical_address);

uint64_t pmm_get_total_pages(void);
uint64_t pmm_get_used_pages(void);
uint64_t pmm_get_free_pages(void);

uint64_t pmm_get_allocation_count(void);
uint64_t pmm_get_release_count(void);

/* PMM diagnostic functions. */
int pmm_is_managed_page(uint64_t physical_address);
int pmm_is_reserved_page(uint64_t physical_address);

#endif
