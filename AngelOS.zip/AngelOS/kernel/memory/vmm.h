#ifndef HALOROOT_VMM_H
#define HALOROOT_VMM_H

#include <stdint.h>

struct limine_hhdm_response {
    uint64_t revision;
    uint64_t offset;
};

struct limine_hhdm_request {
    uint64_t id[4];
    uint64_t revision;
    struct limine_hhdm_response *response;
};

#define VMM_PAGE_PRESENT  (1ULL << 0)
#define VMM_PAGE_WRITABLE (1ULL << 1)
#define VMM_PAGE_USER     (1ULL << 2)
#define VMM_PAGE_HUGE     (1ULL << 7)
#define VMM_PAGE_NX       (1ULL << 63)

struct vmm_mapping_info {
    int mapped;
    int page_size;
    int writable;
    int user;
    int executable;
    uint64_t physical_address;
    uint64_t page_entry;
};

int vmm_init(const struct limine_hhdm_response *response);

uint64_t vmm_get_hhdm_offset(void);
uint64_t vmm_get_current_pml4(void);

uintptr_t vmm_phys_to_virt(uint64_t physical_address);

int vmm_get_mapping(
    uintptr_t virtual_address,
    struct vmm_mapping_info *info
);

int vmm_get_hhdm_mapping(
    uint64_t physical_address,
    struct vmm_mapping_info *info
);

/* Map a physical 4 KiB page at its corresponding HHDM address. */
int vmm_map_hhdm_page(uint64_t physical_address);

#endif