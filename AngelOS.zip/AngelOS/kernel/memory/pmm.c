
#include "pmm.h"

/*
 * HaloRoot Physical Memory Manager — 0.6
 *
 * - 4 KiB physical pages
 * - Manages physical memory below 4 GiB
 * - Allocates only Limine USABLE memory
 * - Reserves the first 1 MiB
 * - Protects the kernel image
 * - Tracks total, used and free pages
 * - Counts successful allocations and releases
 * - Provides memory reservation diagnostics
 */

#define PMM_MAX_PHYSICAL_ADDRESS (4ULL * 1024 * 1024 * 1024)

#define PMM_MAX_FRAMES \
    (PMM_MAX_PHYSICAL_ADDRESS / PMM_PAGE_SIZE)

#define PMM_BITMAP_BYTES \
    ((PMM_MAX_FRAMES + 7) / 8)

#define LIMINE_MEMMAP_USABLE 0

static uint8_t used_bitmap[PMM_BITMAP_BYTES];
static uint8_t managed_bitmap[PMM_BITMAP_BYTES];
static uint8_t reserved_bitmap[PMM_BITMAP_BYTES];

static uint64_t total_pages = 0;
static uint64_t free_pages = 0;

static uint64_t allocation_count = 0;
static uint64_t release_count = 0;

static uint64_t search_hint = 0;

static int bit_test(const uint8_t *bitmap, uint64_t frame)
{
    return (bitmap[frame / 8] >> (frame % 8)) & 1;
}

static void bit_set(uint8_t *bitmap, uint64_t frame)
{
    bitmap[frame / 8] |= (uint8_t)(1U << (frame % 8));
}

static void bit_clear(uint8_t *bitmap, uint64_t frame)
{
    bitmap[frame / 8] &= (uint8_t)~(1U << (frame % 8));
}

/*
 * Reserve a physical address range.
 * The end address is exclusive.
 */
static void reserve_range(uint64_t start, uint64_t end)
{
    if (end <= start) {
        return;
    }

    uint64_t first_frame = start / PMM_PAGE_SIZE;
    uint64_t last_frame = end / PMM_PAGE_SIZE;

    if ((end % PMM_PAGE_SIZE) != 0) {
        last_frame++;
    }

    if (first_frame >= PMM_MAX_FRAMES) {
        return;
    }

    if (last_frame > PMM_MAX_FRAMES) {
        last_frame = PMM_MAX_FRAMES;
    }

    for (uint64_t frame = first_frame;
         frame < last_frame;
         frame++) {

        bit_set(reserved_bitmap, frame);

        if (bit_test(managed_bitmap, frame) &&
            !bit_test(used_bitmap, frame)) {

            bit_set(used_bitmap, frame);
            free_pages--;
        }
    }
}

int pmm_init(
    const struct limine_memmap_response *response,
    uint64_t kernel_physical_start,
    uint64_t kernel_physical_end
)
{
    if (response == 0 ||
        response->entries == 0 ||
        response->entry_count == 0) {
        return 0;
    }

    /* Initially, every page is unavailable. */

    for (uint64_t i = 0; i < PMM_BITMAP_BYTES; i++) {
        used_bitmap[i] = 0xFF;
        managed_bitmap[i] = 0x00;
        reserved_bitmap[i] = 0x00;
    }

    total_pages = 0;
    free_pages = 0;

    allocation_count = 0;
    release_count = 0;

    search_hint = 0;

    /* Make usable physical memory available. */

    for (uint64_t i = 0; i < response->entry_count; i++) {

        const struct limine_memmap_entry *entry =
            response->entries[i];

        if (entry == 0 ||
            entry->type != LIMINE_MEMMAP_USABLE) {
            continue;
        }

        if (entry->length == 0 ||
            entry->base > UINT64_MAX - entry->length) {
            continue;
        }

        uint64_t start = entry->base;
        uint64_t end = entry->base + entry->length;

        /* Keep the first 1 MiB reserved. */

        if (start < 0x100000ULL) {
            start = 0x100000ULL;
        }

        if (start > UINT64_MAX - (PMM_PAGE_SIZE - 1)) {
            continue;
        }

        start = (start + PMM_PAGE_SIZE - 1)
                & ~(PMM_PAGE_SIZE - 1);

        end &= ~(PMM_PAGE_SIZE - 1);

        if (start >= PMM_MAX_PHYSICAL_ADDRESS) {
            continue;
        }

        if (end > PMM_MAX_PHYSICAL_ADDRESS) {
            end = PMM_MAX_PHYSICAL_ADDRESS;
        }

        if (start >= end) {
            continue;
        }

        uint64_t first_frame = start / PMM_PAGE_SIZE;
        uint64_t last_frame = end / PMM_PAGE_SIZE;

        for (uint64_t frame = first_frame;
             frame < last_frame;
             frame++) {

            if (!bit_test(managed_bitmap, frame)) {
                bit_set(managed_bitmap, frame);
                bit_clear(used_bitmap, frame);

                total_pages++;
                free_pages++;
            }
        }
    }

    /* Protect the complete kernel image. */

    reserve_range(
        kernel_physical_start,
        kernel_physical_end
    );

    return free_pages > 0;
}

uint64_t pmm_alloc_page(void)
{
    if (free_pages == 0) {
        return 0;
    }

    for (uint64_t offset = 0;
         offset < PMM_MAX_FRAMES;
         offset++) {

        uint64_t frame = search_hint + offset;

        if (frame >= PMM_MAX_FRAMES) {
            frame -= PMM_MAX_FRAMES;
        }

        if (bit_test(managed_bitmap, frame) &&
            !bit_test(used_bitmap, frame) &&
            !bit_test(reserved_bitmap, frame)) {

            bit_set(used_bitmap, frame);

            free_pages--;
            allocation_count++;

            search_hint = frame + 1;

            if (search_hint >= PMM_MAX_FRAMES) {
                search_hint = 0;
            }

            return frame * PMM_PAGE_SIZE;
        }
    }

    return 0;
}

int pmm_free_page(uint64_t physical_address)
{
    if (physical_address == 0 ||
        physical_address % PMM_PAGE_SIZE != 0) {
        return 0;
    }

    uint64_t frame = physical_address / PMM_PAGE_SIZE;

    if (frame >= PMM_MAX_FRAMES) {
        return 0;
    }

    if (!bit_test(managed_bitmap, frame) ||
        !bit_test(used_bitmap, frame) ||
        bit_test(reserved_bitmap, frame)) {
        return 0;
    }

    bit_clear(used_bitmap, frame);

    free_pages++;
    release_count++;

    if (frame < search_hint) {
        search_hint = frame;
    }

    return 1;
}

/* Memory statistics. */

uint64_t pmm_get_total_pages(void)
{
    return total_pages;
}

uint64_t pmm_get_used_pages(void)
{
    return total_pages - free_pages;
}

uint64_t pmm_get_free_pages(void)
{
    return free_pages;
}

/* Allocation statistics. */

uint64_t pmm_get_allocation_count(void)
{
    return allocation_count;
}

uint64_t pmm_get_release_count(void)
{
    return release_count;
}

/* Diagnostic functions. */

int pmm_is_managed_page(uint64_t physical_address)
{
    if (physical_address % PMM_PAGE_SIZE != 0) {
        return 0;
    }

    uint64_t frame = physical_address / PMM_PAGE_SIZE;

    if (frame >= PMM_MAX_FRAMES) {
        return 0;
    }

    return bit_test(managed_bitmap, frame);
}

int pmm_is_reserved_page(uint64_t physical_address)
{
    if (physical_address % PMM_PAGE_SIZE != 0) {
        return 0;
    }

    uint64_t frame = physical_address / PMM_PAGE_SIZE;

    if (frame >= PMM_MAX_FRAMES) {
        return 0;
    }

    return bit_test(reserved_bitmap, frame);
}
