#include "vmm.h"
#include "pmm.h"

static uint64_t hhdm_offset = 0;
static int vmm_initialized = 0;

#define PAGE_ADDRESS_MASK 0x000FFFFFFFFFF000ULL

#define PAGE_SIZE_4K 4096ULL
#define PAGE_ENTRIES 512

static uint64_t read_page_entry(
    uint64_t table_physical,
    uint64_t index
)
{
    uint64_t table_virtual =
        table_physical + hhdm_offset;

    volatile uint64_t *table =
        (volatile uint64_t *)(uintptr_t)table_virtual;

    return table[index];
}

static volatile uint64_t *get_page_table(uint64_t physical)
{
    uintptr_t virtual_address =
        vmm_phys_to_virt(physical);

    if (virtual_address == 0) {
        return 0;
    }

    return (volatile uint64_t *)virtual_address;
}

/*
 * Allocate a new page-table page.
 * The page must be accessible through the HHDM.
 */
static uint64_t allocate_page_table(void)
{
    uint64_t physical = pmm_alloc_page();

    if (physical == 0) {
        return 0;
    }

    volatile uint64_t *table =
        get_page_table(physical);

    if (table == 0) {
        pmm_free_page(physical);
        return 0;
    }

    for (uint64_t i = 0; i < PAGE_ENTRIES; i++) {
        table[i] = 0;
    }

    return physical;
}

/*
 * Ensure that an intermediate page-table entry points
 * to a valid lower-level table.
 *
 * Returns 1 on success.
 */
static int ensure_page_table(uint64_t *entry)
{
    if (*entry & VMM_PAGE_PRESENT) {

        /* A huge page is already mapped at this level. */
        if (*entry & VMM_PAGE_HUGE) {
            return 0;
        }

        /* Make the lower-level table writable. */
        *entry |= VMM_PAGE_WRITABLE;

        return 1;
    }

    uint64_t new_table = allocate_page_table();

    if (new_table == 0) {
        return 0;
    }

    *entry =
        (new_table & PAGE_ADDRESS_MASK) |
        VMM_PAGE_PRESENT |
        VMM_PAGE_WRITABLE;

    return 1;
}

int vmm_init(const struct limine_hhdm_response *response)
{
    if (response == 0 || response->offset == 0) {
        return 0;
    }

    hhdm_offset = response->offset;
    vmm_initialized = 1;

    return 1;
}

uint64_t vmm_get_hhdm_offset(void)
{
    return hhdm_offset;
}

uint64_t vmm_get_current_pml4(void)
{
    uint64_t cr3;

    __asm__ volatile (
        "mov %%cr3, %0"
        : "=r"(cr3)
    );

    return cr3 & PAGE_ADDRESS_MASK;
}

uintptr_t vmm_phys_to_virt(uint64_t physical_address)
{
    if (!vmm_initialized) {
        return 0;
    }

    if (physical_address > UINTPTR_MAX - hhdm_offset) {
        return 0;
    }

    return (uintptr_t)(physical_address + hhdm_offset);
}

int vmm_get_mapping(
    uintptr_t virtual_address,
    struct vmm_mapping_info *info
)
{
    if (!vmm_initialized || info == 0) {
        return 0;
    }

    info->mapped = 0;
    info->page_size = 0;
    info->writable = 0;
    info->user = 0;
    info->executable = 0;
    info->physical_address = 0;
    info->page_entry = 0;

    uint64_t pml4 = vmm_get_current_pml4();

    uint64_t pml4_index =
        ((uint64_t)virtual_address >> 39) & 0x1FF;

    uint64_t pdpt_index =
        ((uint64_t)virtual_address >> 30) & 0x1FF;

    uint64_t pd_index =
        ((uint64_t)virtual_address >> 21) & 0x1FF;

    uint64_t pt_index =
        ((uint64_t)virtual_address >> 12) & 0x1FF;

    uint64_t pml4_entry =
        read_page_entry(pml4, pml4_index);

    if (!(pml4_entry & VMM_PAGE_PRESENT)) {
        return 1;
    }

    uint64_t pdpt =
        pml4_entry & PAGE_ADDRESS_MASK;

    uint64_t pdpt_entry =
        read_page_entry(pdpt, pdpt_index);

    if (!(pdpt_entry & VMM_PAGE_PRESENT)) {
        return 1;
    }

    uint64_t permissions =
        pml4_entry & pdpt_entry;

    if (pdpt_entry & VMM_PAGE_HUGE) {
        info->mapped = 1;
        info->page_size = 1073741824;

        info->physical_address =
            (pdpt_entry & 0x000FFFFFC0000000ULL) |
            ((uint64_t)virtual_address & 0x3FFFFFFFULL);

        info->page_entry = pdpt_entry;

        info->writable =
            (permissions & VMM_PAGE_WRITABLE) != 0;

        info->user =
            (permissions & VMM_PAGE_USER) != 0;

        info->executable =
            (permissions & VMM_PAGE_NX) == 0;

        return 1;
    }

    uint64_t pd =
        pdpt_entry & PAGE_ADDRESS_MASK;

    uint64_t pd_entry =
        read_page_entry(pd, pd_index);

    if (!(pd_entry & VMM_PAGE_PRESENT)) {
        return 1;
    }

    permissions &= pd_entry;

    if (pd_entry & VMM_PAGE_HUGE) {
        info->mapped = 1;
        info->page_size = 2097152;

        info->physical_address =
            (pd_entry & 0x000FFFFFFFE00000ULL) |
            ((uint64_t)virtual_address & 0x1FFFFFULL);

        info->page_entry = pd_entry;

        info->writable =
            (permissions & VMM_PAGE_WRITABLE) != 0;

        info->user =
            (permissions & VMM_PAGE_USER) != 0;

        info->executable =
            (permissions & VMM_PAGE_NX) == 0;

        return 1;
    }

    uint64_t pt =
        pd_entry & PAGE_ADDRESS_MASK;

    uint64_t pt_entry =
        read_page_entry(pt, pt_index);

    if (!(pt_entry & VMM_PAGE_PRESENT)) {
        return 1;
    }

    permissions &= pt_entry;

    info->mapped = 1;
    info->page_size = 4096;

    info->physical_address =
        (pt_entry & PAGE_ADDRESS_MASK) |
        ((uint64_t)virtual_address & 0xFFFULL);

    info->page_entry = pt_entry;

    info->writable =
        (permissions & VMM_PAGE_WRITABLE) != 0;

    info->user =
        (permissions & VMM_PAGE_USER) != 0;

    info->executable =
        (permissions & VMM_PAGE_NX) == 0;

    return 1;
}

int vmm_get_hhdm_mapping(
    uint64_t physical_address,
    struct vmm_mapping_info *info
)
{
    if (!vmm_initialized ||
        physical_address > UINTPTR_MAX - hhdm_offset) {
        return 0;
    }

    uintptr_t virtual_address =
        (uintptr_t)(physical_address + hhdm_offset);

    return vmm_get_mapping(virtual_address, info);
}

/*
 * Map a physical 4 KiB page at:
 *
 *     HHDM offset + physical address
 *
 * Missing intermediate page tables are allocated
 * from the PMM.
 */
int vmm_map_hhdm_page(uint64_t physical_address)
{
    if (!vmm_initialized) {
        return 0;
    }

    physical_address &= ~(PAGE_SIZE_4K - 1);

    if (physical_address > UINTPTR_MAX - hhdm_offset) {
        return 0;
    }

    uintptr_t virtual_address =
        (uintptr_t)(hhdm_offset + physical_address);

    /* Already mapped? Nothing to do. */
    struct vmm_mapping_info info;

    if (!vmm_get_mapping(virtual_address, &info)) {
        return 0;
    }

    if (info.mapped) {
        return 1;
    }

    uint64_t pml4_physical =
        vmm_get_current_pml4();

    volatile uint64_t *pml4 =
        get_page_table(pml4_physical);

    if (pml4 == 0) {
        return 0;
    }

    uint64_t pml4_index =
        ((uint64_t)virtual_address >> 39) & 0x1FF;

    uint64_t pdpt_index =
        ((uint64_t)virtual_address >> 30) & 0x1FF;

    uint64_t pd_index =
        ((uint64_t)virtual_address >> 21) & 0x1FF;

    uint64_t pt_index =
        ((uint64_t)virtual_address >> 12) & 0x1FF;

    /* PML4 -> PDPT */

    if (!ensure_page_table((uint64_t *)&pml4[pml4_index])) {
        return 0;
    }

    uint64_t pdpt_physical =
        pml4[pml4_index] & PAGE_ADDRESS_MASK;

    volatile uint64_t *pdpt =
        get_page_table(pdpt_physical);

    if (pdpt == 0) {
        return 0;
    }

    /* PDPT -> PD */

    if (!ensure_page_table((uint64_t *)&pdpt[pdpt_index])) {
        return 0;
    }

    uint64_t pd_physical =
        pdpt[pdpt_index] & PAGE_ADDRESS_MASK;

    volatile uint64_t *pd =
        get_page_table(pd_physical);

    if (pd == 0) {
        return 0;
    }

    /* PD -> PT */

    if (!ensure_page_table((uint64_t *)&pd[pd_index])) {
        return 0;
    }

    uint64_t pt_physical =
        pd[pd_index] & PAGE_ADDRESS_MASK;

    volatile uint64_t *pt =
        get_page_table(pt_physical);

    if (pt == 0) {
        return 0;
    }

    /* PT -> physical page */

    if (pt[pt_index] & VMM_PAGE_PRESENT) {
        return 1;
    }

    pt[pt_index] =
        (physical_address & PAGE_ADDRESS_MASK) |
        VMM_PAGE_PRESENT |
        VMM_PAGE_WRITABLE;

    /* Invalidate this virtual address in the TLB. */

    __asm__ volatile (
        "invlpg (%0)"
        :
        : "r"(virtual_address)
        : "memory"
    );

    return 1;
}