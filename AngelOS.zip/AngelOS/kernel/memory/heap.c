
#include "heap.h"

#include "pmm.h"
#include "vmm.h"

#define HEAP_PAGE_SIZE 4096ULL
#define HEAP_ALIGNMENT 16ULL

#define HEAP_PAGE_MAGIC  0x4845415050414745ULL
#define HEAP_BLOCK_MAGIC 0x48454150424C4F43ULL

#define BLOCK_FREE 1ULL
#define BLOCK_USED 0ULL

struct heap_page {
    uint64_t magic;
    uint64_t physical_address;
    struct heap_page *next;
    uint64_t reserved;
} __attribute__((aligned(16)));

struct heap_block {
    size_t size;
    size_t previous_size;
    size_t requested_size;

    struct heap_block *next_free;
    struct heap_block *previous_free;

    uint64_t magic;
    uint64_t flags;
} __attribute__((aligned(16)));

static struct heap_page *page_list = 0;
static struct heap_block *free_list = 0;

static uint64_t page_count = 0;
static uint64_t free_block_count = 0;

static int heap_initialized = 0;

static size_t align_up(size_t size)
{
    return (size + HEAP_ALIGNMENT - 1) & ~(HEAP_ALIGNMENT - 1);
}

static struct heap_page *get_page(struct heap_block *block)
{
    uintptr_t address = (uintptr_t)block;

    address &= ~(HEAP_PAGE_SIZE - 1);

    return (struct heap_page *)address;
}

static void remove_free_block(struct heap_block *block)
{
    if (block->previous_free != 0) {
        block->previous_free->next_free = block->next_free;
    } else {
        free_list = block->next_free;
    }

    if (block->next_free != 0) {
        block->next_free->previous_free = block->previous_free;
    }

    block->next_free = 0;
    block->previous_free = 0;

    if (free_block_count > 0) {
        free_block_count--;
    }
}

static void add_free_block(struct heap_block *block)
{
    block->flags = BLOCK_FREE;

    block->previous_free = 0;
    block->next_free = free_list;

    if (free_list != 0) {
        free_list->previous_free = block;
    }

    free_list = block;
    free_block_count++;
}

static int heap_add_page(void)
{
    uint64_t physical = pmm_alloc_page();

    if (physical == 0) {
        return 0;
    }

    uintptr_t virtual_address = vmm_phys_to_virt(physical);

    if (virtual_address == 0) {
        pmm_free_page(physical);
        return 0;
    }

    struct heap_page *page =
        (struct heap_page *)virtual_address;

    page->magic = HEAP_PAGE_MAGIC;
    page->physical_address = physical;
    page->next = page_list;
    page->reserved = 0;

    page_list = page;
    page_count++;

    struct heap_block *block =
        (struct heap_block *)(
            virtual_address + sizeof(struct heap_page)
        );

    block->size =
        HEAP_PAGE_SIZE - sizeof(struct heap_page);

    block->previous_size = 0;
    block->requested_size = 0;

    block->magic = HEAP_BLOCK_MAGIC;

    block->next_free = 0;
    block->previous_free = 0;

    add_free_block(block);

    return 1;
}

int heap_init(void)
{
    if (heap_initialized) {
        return 1;
    }

    if (vmm_get_hhdm_offset() == 0) {
        return 0;
    }

    if (pmm_get_free_pages() == 0) {
        return 0;
    }

    heap_initialized = 1;

    return 1;
}

void *kmalloc(size_t size)
{
    if (!heap_initialized || size == 0) {
        return 0;
    }

    if (size > SIZE_MAX - (HEAP_ALIGNMENT - 1)) {
        return 0;
    }

    size_t aligned_size = align_up(size);

    size_t maximum_size =
        HEAP_PAGE_SIZE
        - sizeof(struct heap_page)
        - sizeof(struct heap_block);

    if (aligned_size > maximum_size) {
        return 0;
    }

    size_t required_size =
        sizeof(struct heap_block) + aligned_size;

    struct heap_block *block = free_list;

    while (block != 0 && block->size < required_size) {
        block = block->next_free;
    }

    if (block == 0) {
        if (!heap_add_page()) {
            return 0;
        }

        block = free_list;
    }

    if (block == 0 || block->size < required_size) {
        return 0;
    }

    remove_free_block(block);

    size_t remaining_size = block->size - required_size;

    if (remaining_size >=
        sizeof(struct heap_block) + HEAP_ALIGNMENT) {

        size_t original_size = block->size;

        block->size = required_size;

        struct heap_block *split =
            (struct heap_block *)(
                (uintptr_t)block + required_size
            );

        split->size = original_size - required_size;
        split->previous_size = required_size;
        split->requested_size = 0;

        split->magic = HEAP_BLOCK_MAGIC;

        split->next_free = 0;
        split->previous_free = 0;

        struct heap_page *page = get_page(block);

        uintptr_t page_end =
            (uintptr_t)page + HEAP_PAGE_SIZE;

        uintptr_t next_address =
            (uintptr_t)split + split->size;

        if (next_address < page_end) {
            struct heap_block *next =
                (struct heap_block *)next_address;

            next->previous_size = split->size;
        }

        add_free_block(split);
    }

    block->requested_size = size;
    block->flags = BLOCK_USED;

    block->next_free = 0;
    block->previous_free = 0;

    return (void *)(
        (uintptr_t)block + sizeof(struct heap_block)
    );
}

void kfree(void *pointer)
{
    if (!heap_initialized || pointer == 0) {
        return;
    }

    struct heap_block *block =
        (struct heap_block *)(
            (uintptr_t)pointer - sizeof(struct heap_block)
        );

    if (block->magic != HEAP_BLOCK_MAGIC) {
        return;
    }

    if (block->flags != BLOCK_USED) {
        return;
    }

    struct heap_page *page = get_page(block);

    if (page->magic != HEAP_PAGE_MAGIC) {
        return;
    }

    block->flags = BLOCK_FREE;
    block->requested_size = 0;

    uintptr_t page_start = (uintptr_t)page;
    uintptr_t page_end = page_start + HEAP_PAGE_SIZE;

    /* Merge with the previous block if it is free. */

    if (block->previous_size != 0) {
        struct heap_block *previous =
            (struct heap_block *)(
                (uintptr_t)block - block->previous_size
            );

        if ((uintptr_t)previous >=
                page_start + sizeof(struct heap_page) &&
            previous->magic == HEAP_BLOCK_MAGIC &&
            previous->flags == BLOCK_FREE) {

            remove_free_block(previous);

            previous->size += block->size;
            block = previous;
        }
    }

    /* Merge with the next block if it is free. */

    uintptr_t next_address =
        (uintptr_t)block + block->size;

    if (next_address < page_end) {
        struct heap_block *next =
            (struct heap_block *)next_address;

        if (next->magic == HEAP_BLOCK_MAGIC &&
            next->flags == BLOCK_FREE) {

            remove_free_block(next);

            block->size += next->size;
        }
    }

    /* Update the following block's boundary information. */

    next_address = (uintptr_t)block + block->size;

    if (next_address < page_end) {
        struct heap_block *next =
            (struct heap_block *)next_address;

        next->previous_size = block->size;
    }

    add_free_block(block);
}

void *kcalloc(size_t count, size_t size)
{
    if (count == 0 || size == 0) {
        return 0;
    }

    if (size > SIZE_MAX / count) {
        return 0;
    }

    size_t total_size = count * size;

    void *memory = kmalloc(total_size);

    if (memory == 0) {
        return 0;
    }

    uint8_t *bytes = (uint8_t *)memory;

    for (size_t i = 0; i < total_size; i++) {
        bytes[i] = 0;
    }

    return memory;
}

void *krealloc(void *pointer, size_t size)
{
    if (pointer == 0) {
        return kmalloc(size);
    }

    if (size == 0) {
        kfree(pointer);
        return 0;
    }

    struct heap_block *block =
        (struct heap_block *)(
            (uintptr_t)pointer - sizeof(struct heap_block)
        );

    if (block->magic != HEAP_BLOCK_MAGIC ||
        block->flags != BLOCK_USED) {
        return 0;
    }

    size_t old_size = block->requested_size;

    size_t capacity =
        block->size - sizeof(struct heap_block);

    if (size <= capacity) {
        block->requested_size = size;
        return pointer;
    }

    void *new_memory = kmalloc(size);

    if (new_memory == 0) {
        return 0;
    }

    uint8_t *source = (uint8_t *)pointer;
    uint8_t *destination = (uint8_t *)new_memory;

    size_t copy_size = old_size < size ? old_size : size;

    for (size_t i = 0; i < copy_size; i++) {
        destination[i] = source[i];
    }

    kfree(pointer);

    return new_memory;
}

uint64_t heap_get_page_count(void)
{
    return page_count;
}

uint64_t heap_get_free_block_count(void)
{
    return free_block_count;
}
