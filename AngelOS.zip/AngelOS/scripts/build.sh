
#!/bin/sh
set -eu

echo "================================"
echo "       Building AngelOS"
echo "       HaloRoot 1.3"
echo "================================"

mkdir -p build
mkdir -p iso_root/boot/limine
mkdir -p iso_root/EFI/BOOT

echo "[1/17] Assembling kernel entry..."

nasm -f elf64 kernel/entry.asm \
    -o build/entry.o

echo "[2/17] Compiling HaloRoot kernel..."

gcc \
    -std=c11 \
    -O2 \
    -Wall \
    -Wextra \
    -Werror \
    -ffreestanding \
    -fno-builtin \
    -fno-stack-protector \
    -fno-pic \
    -fno-pie \
    -fno-asynchronous-unwind-tables \
    -fno-unwind-tables \
    -m64 \
    -mno-red-zone \
    -mcmodel=kernel \
    -mno-mmx \
    -mno-sse \
    -mno-sse2 \
    -c kernel/main.c \
    -o build/main.o

echo "[3/17] Compiling physical memory manager..."

gcc \
    -std=c11 \
    -O2 \
    -Wall \
    -Wextra \
    -Werror \
    -ffreestanding \
    -fno-builtin \
    -fno-stack-protector \
    -fno-pic \
    -fno-pie \
    -fno-asynchronous-unwind-tables \
    -fno-unwind-tables \
    -m64 \
    -mno-red-zone \
    -mcmodel=kernel \
    -mno-mmx \
    -mno-sse \
    -mno-sse2 \
    -c kernel/memory/pmm.c \
    -o build/pmm.o

echo "[4/17] Compiling virtual memory manager..."

gcc \
    -std=c11 \
    -O2 \
    -Wall \
    -Wextra \
    -Werror \
    -ffreestanding \
    -fno-builtin \
    -fno-stack-protector \
    -fno-pic \
    -fno-pie \
    -fno-asynchronous-unwind-tables \
    -fno-unwind-tables \
    -m64 \
    -mno-red-zone \
    -mcmodel=kernel \
    -mno-mmx \
    -mno-sse \
    -mno-sse2 \
    -c kernel/memory/vmm.c \
    -o build/vmm.o

echo "[5/17] Compiling kernel heap manager..."

gcc \
    -std=c11 \
    -O2 \
    -Wall \
    -Wextra \
    -Werror \
    -ffreestanding \
    -fno-builtin \
    -fno-stack-protector \
    -fno-pic \
    -fno-pie \
    -fno-asynchronous-unwind-tables \
    -fno-unwind-tables \
    -m64 \
    -mno-red-zone \
    -mcmodel=kernel \
    -mno-mmx \
    -mno-sse \
    -mno-sse2 \
    -c kernel/memory/heap.c \
    -o build/heap.o

echo "[6/17] Compiling IDT..."

gcc \
    -std=c11 \
    -O2 \
    -Wall \
    -Wextra \
    -Werror \
    -ffreestanding \
    -fno-builtin \
    -fno-stack-protector \
    -fno-pic \
    -fno-pie \
    -fno-asynchronous-unwind-tables \
    -fno-unwind-tables \
    -m64 \
    -mno-red-zone \
    -mcmodel=kernel \
    -mno-mmx \
    -mno-sse \
    -mno-sse2 \
    -c kernel/interrupts/idt.c \
    -o build/idt.o

echo "[7/17] Compiling interrupt handlers..."

gcc \
    -std=c11 \
    -O2 \
    -Wall \
    -Wextra \
    -Werror \
    -ffreestanding \
    -fno-builtin \
    -fno-stack-protector \
    -fno-pic \
    -fno-pie \
    -fno-asynchronous-unwind-tables \
    -fno-unwind-tables \
    -m64 \
    -mno-red-zone \
    -mcmodel=kernel \
    -mno-mmx \
    -mno-sse \
    -mno-sse2 \
    -c kernel/interrupts/interrupts.c \
    -o build/interrupts.o

echo "[8/17] Compiling Programmable Interrupt Controller..."

gcc \
    -std=c11 \
    -O2 \
    -Wall \
    -Wextra \
    -Werror \
    -ffreestanding \
    -fno-builtin \
    -fno-stack-protector \
    -fno-pic \
    -fno-pie \
    -fno-asynchronous-unwind-tables \
    -fno-unwind-tables \
    -m64 \
    -mno-red-zone \
    -mcmodel=kernel \
    -mno-mmx \
    -mno-sse \
    -mno-sse2 \
    -c kernel/interrupts/pic.c \
    -o build/pic.o

echo "[9/17] Compiling Programmable Interval Timer..."

gcc \
    -std=c11 \
    -O2 \
    -Wall \
    -Wextra \
    -Werror \
    -ffreestanding \
    -fno-builtin \
    -fno-stack-protector \
    -fno-pic \
    -fno-pie \
    -fno-asynchronous-unwind-tables \
    -fno-unwind-tables \
    -m64 \
    -mno-red-zone \
    -mcmodel=kernel \
    -mno-mmx \
    -mno-sse \
    -mno-sse2 \
    -c kernel/drivers/pit.c \
    -o build/pit.o

echo "[10/17] Compiling keyboard driver..."

gcc \
    -std=c11 \
    -O2 \
    -Wall \
    -Wextra \
    -Werror \
    -ffreestanding \
    -fno-builtin \
    -fno-stack-protector \
    -fno-pic \
    -fno-pie \
    -fno-asynchronous-unwind-tables \
    -fno-unwind-tables \
    -m64 \
    -mno-red-zone \
    -mcmodel=kernel \
    -mno-mmx \
    -mno-sse \
    -mno-sse2 \
    -c kernel/drivers/keyboard.c \
    -o build/keyboard.o

echo "[11/17] Compiling Real-Time Clock..."

gcc \
    -std=c11 \
    -O2 \
    -Wall \
    -Wextra \
    -Werror \
    -ffreestanding \
    -fno-builtin \
    -fno-stack-protector \
    -fno-pic \
    -fno-pie \
    -fno-asynchronous-unwind-tables \
    -fno-unwind-tables \
    -m64 \
    -mno-red-zone \
    -mcmodel=kernel \
    -mno-mmx \
    -mno-sse \
    -mno-sse2 \
    -c kernel/drivers/rtc.c \
    -o build/rtc.o

echo "[12/17] Compiling RAM filesystem..."

gcc \
    -std=c11 \
    -O2 \
    -Wall \
    -Wextra \
    -Werror \
    -ffreestanding \
    -fno-builtin \
    -fno-stack-protector \
    -fno-pic \
    -fno-pie \
    -fno-asynchronous-unwind-tables \
    -fno-unwind-tables \
    -m64 \
    -mno-red-zone \
    -mcmodel=kernel \
    -mno-mmx \
    -mno-sse \
    -mno-sse2 \
    -c kernel/fs/fs.c \
    -o build/fs.o

echo "[13/18] Compiling ATA disk driver..."

gcc \
    -std=c11 \
    -O2 \
    -Wall \
    -Wextra \
    -Werror \
    -ffreestanding \
    -fno-builtin \
    -fno-stack-protector \
    -fno-pic \
    -fno-pie \
    -fno-asynchronous-unwind-tables \
    -fno-unwind-tables \
    -m64 \
    -mno-red-zone \
    -mcmodel=kernel \
    -mno-mmx \
    -mno-sse \
    -mno-sse2 \
    -c kernel/drivers/ata.c \
    -o build/ata.o

echo "[14/17] Assembling interrupt stubs..."

nasm -f elf64 kernel/interrupts/isr.asm \
    -o build/isr.o

echo "[15/17] Linking kernel..."

ld \
    -m elf_x86_64 \
    -nostdlib \
    -static \
    -z max-page-size=0x1000 \
    -T kernel/linker.ld \
    -o build/haloroot.elf \
    build/entry.o \
    build/main.o \
    build/pmm.o \
    build/vmm.o \
    build/heap.o \
    build/idt.o \
    build/interrupts.o \
    build/pic.o \
    build/pit.o \
    build/keyboard.o \
    build/rtc.o \
    build/fs.o \
    build/ata.o \
    build/isr.o

echo "[16/17] Preparing boot image..."

cp build/haloroot.elf iso_root/boot/haloroot.elf

cp boot/limine.conf iso_root/boot/limine/limine.conf

cp tools/limine-binary/limine-bios.sys \
    iso_root/boot/limine/

cp tools/limine-binary/limine-bios-cd.bin \
    iso_root/boot/limine/

cp tools/limine-binary/limine-uefi-cd.bin \
    iso_root/boot/limine/

cp tools/limine-binary/BOOTX64.EFI \
    iso_root/EFI/BOOT/

echo "[17/18] Creating bootable ISO..."

xorriso -as mkisofs -R -r -J \
    -b boot/limine/limine-bios-cd.bin \
    -no-emul-boot \
    -boot-load-size 4 \
    -boot-info-table \
    -eltorito-alt-boot \
    -e boot/limine/limine-uefi-cd.bin \
    -no-emul-boot \
    iso_root -o build/AngelOS.iso

echo "[18/18] BIOS installation skipped (temporary)."

# tools/limine-binary/limine bios-install build/AngelOS.iso

echo "================================"
echo "       BUILD SUCCESSFUL"
echo "================================"
echo "Kernel: build/haloroot.elf"
echo "ISO:    build/AngelOS.iso"
